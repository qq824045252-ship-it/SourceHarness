# Operations policy POL-083
Only the primary section moves to the policy settings.
Its timeout is 45.
Its retry count is 5.
Use the policy identifier in the evidence note.
