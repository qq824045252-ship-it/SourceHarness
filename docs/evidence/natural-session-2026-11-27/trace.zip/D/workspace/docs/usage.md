# Usage

Generates a per-instrument sampling report from one or more CSVs of raw samples.
The business rules live in [docs/report_policy.md](report_policy.md); this page
explains how to run the tool and what it produces.

## Requirements

Python 3.8 or newer. The tool uses only the standard library, so there is
nothing to install.

## Command

    python sample_report.py --input data/day1.csv --output summary.csv

Read several files at once by repeating `--input` (here all three days), and
optionally record the skipped samples with `--issues`:

    python sample_report.py --input data/day1.csv --input data/day2.csv \
        --input data/day3.csv --output summary.csv --issues issues.csv

| Argument     | Meaning                                                              |
| ------------ | -------------------------------------------------------------------- |
| `--input`    | Path of a sample CSV to read. Required, and may be repeated. Files are read in the order given. Read-only, never modified. |
| `--output`   | Path of the summary CSV to write. Required. Overwritten if it exists. |
| `--issues`   | Optional path of the issues CSV listing skipped samples. Omitted means no issues file is written. |

A single `--input` behaves exactly as it did before `--input` became
repeatable.

On success the tool prints what it did and exits with status `0`, for example
for the three-day run:

    Read 10 sample(s) from 3 file(s): 2 duplicate(s), 2 issue(s)
    Wrote 4 instrument(s) to summary.csv
    Wrote 2 issue(s) to issues.csv

If a `sample_id` has conflicting contents the tool prints an `error: ...` line
on standard error, exits with status `2`, and writes no report or issues file.
A missing or unreadable input file raises an error too, and no output file is
written.

## Combining several files

`--input` may be repeated any number of times. The files are treated as one
stream of samples in the order given, and `sample_id` decides identity:

- **Identical duplicates are counted once.** If the same `sample_id` appears
  again with the same `device_id`, `value` and `status`, the later occurrences
  are dropped and the sample is counted once. This is what makes the example
  files safe to combine: `S-002` appears in both `data/day1.csv` and
  `data/day2.csv` with identical contents, and `S-008` appears in both
  `data/day2.csv` and `data/day3.csv` with identical contents. Each contributes
  a single sample.
- **Conflicts are an error.** If the same `sample_id` appears with different
  contents, the run stops with a clear message naming the sample and both
  sources, for example:

      error: conflicting records for sample_id 'S-003': data/day1.csv has device_id='FT-02', value='-2.005', status='OK' but data/day4.csv has device_id='FT-02', value='3.5', status='OK'

  Nothing is written to `--output` or `--issues` in that case, so a bad merge
  never produces a misleading report.
- **Rows without a `sample_id`** cannot be matched, so each one is kept as its
  own sample. Single-file inputs from the first release are unaffected.

Whitespace around a field is ignored when comparing records, so `FT-01` and
` FT-01 ` are the same instrument and `1.01` and ` 1.01 ` are the same value.
Contents are compared as written otherwise: `1.0` and `1.00` are different
contents for the same `sample_id` and therefore a conflict.

## Input format

A CSV with a header row. The columns used by the report are:

| Column      | Description                                          |
| ----------- | ---------------------------------------------------- |
| `sample_id` | Sample identifier; used to spot duplicates and conflicts. |
| `device_id` | Instrument identifier; samples are grouped by it.     |
| `value`     | Sample reading, parsed as a decimal number.           |
| `status`    | Sample status; the valid statuses are listed in the policy. |

Other columns are ignored. Example (`data/day1.csv`):

    sample_id,device_id,value,status
    S-001,FT-01,1.00,OK
    S-002,FT-01,1.01,OK
    S-003,FT-02,-2.005,OK
    S-WARM-017,FT-02,812.037,WARMUP
    S-004,FT-02,7.25,VALID
    S-005,FT-03,93.3,OFFLINE

and `data/day3.csv`, which also holds a bad value and a device that only appears
there:

    sample_id,device_id,value,status
    S-008,FT-02,1.999,VALID
    S-011,FT-01,4.125,VALID
    S-012,FT-02,-4.50,OK
    S-013,FT-02,bad,VALID
    S-014,FT-04,5.0005,VALID
    S-015,FT-04,123.4,OFFLINE

## Output format

The summary CSV has the header `device_id,count,min,max,mean` and one row per
reported instrument, in the order the instruments first provide a counted
sample.

| Column      | Description                                                    |
| ----------- | -------------------------------------------------------------- |
| `device_id` | Instrument identifier.                                          |
| `count`     | Number of counted samples for that instrument (duplicates already merged). |
| `min`       | Smallest counted value.                                         |
| `max`       | Largest counted value.                                          |
| `mean`      | Average of the counted values, rounded as the policy specifies.  |

## Issues report

`--issues issues.csv` writes a CSV with the header `sample_id,source,reason` and
one row per sample that had a valid status but could not be counted:

| Column      | Description                                                     |
| ----------- | --------------------------------------------------------------- |
| `sample_id` | Identifier of the skipped sample (empty if the row had none).    |
| `source`    | The input file the sample came from.                             |
| `reason`    | Why it was skipped: `invalid numeric value '...'`, `empty value`, or `missing device_id`. |

Rows skipped because of their status are *not* listed — a status that the policy
does not accept is a normal filter, not a defect. That means `WARMUP` and
`OFFLINE` rows stay silent while `bad` and `broken` values are reported. When
there is nothing to report, the file contains only the header row.

## Rules

These rules are defined in [docs/report_policy.md](report_policy.md) and applied
by the tool:

1. **Only valid statuses count.** Per the policy, samples with status `OK` and
   `VALID` count. Rows with any other status (`WARMUP`, `OFFLINE`, ...) are
   skipped, and so are rows whose status is blank or missing. The accepted list
   lives in the policy, so a status change is a policy change.
2. **Identical records count once.** Repeated `sample_id` records with the same
   contents are merged before anything is counted (see *Combining several
   files*). Competing contents for one `sample_id` stop the run with an error.
3. **Only numeric samples count.** A row with a valid status whose `value`
   cannot be parsed as a decimal number (for example `broken` or `bad`) is
   skipped and, when `--issues` is given, reported there with its `sample_id`.
   Blank values are treated the same way. Leading and trailing whitespace is
   ignored, so `" 1.01 "` is read as `1.01`.
4. **Decimal arithmetic.** Statistics are computed with `decimal.Decimal`, not
   binary floats, so values like `-2.005` and `5.0005` are handled exactly.
5. **Mean precision comes from the policy.** The policy currently asks for
   three decimal places with round half up, so a mean of `2.6225` becomes
   `2.623` and `5.0005` becomes `5.001`. Change the number in the policy, not in
   the documentation. `min`, `max` and `count` are not rounded; `min` and `max`
   keep the exact values from the input.
6. **Only instruments with counted samples are reported.** An instrument with
   no counted sample is omitted entirely. If nothing is counted, the summary
   file contains only the header row `device_id,count,min,max,mean`.
7. **Inputs are never modified.** The input CSVs and the policy document are
   read-only; the tool writes only the files named by `--output` and
   `--issues`.

## Examples

### One file

    python sample_report.py --input data/day1.csv --output summary.csv

`summary.csv`:

    device_id,count,min,max,mean
    FT-01,2,1.00,1.01,1.005
    FT-02,2,-2.005,7.25,2.623

`FT-02` counts both its `OK` sample (`-2.005`) and its `VALID` sample (`7.25`),
so its mean is `(-2.005 + 7.25) / 2 = 2.6225`, rounded half up to `2.623`. The
`WARMUP` row is excluded. `FT-03` has no counted sample (`OFFLINE` only) and is
therefore not reported.

### All three days combined, with an issues report

    python sample_report.py --input data/day1.csv --input data/day2.csv \
        --input data/day3.csv --output combined.csv --issues issues.csv

`combined.csv`:

    device_id,count,min,max,mean
    FT-01,4,1.00,4.125,2.335
    FT-02,4,-4.50,7.25,0.686
    FT-03,1,0.75,0.75,0.750
    FT-04,1,5.0005,5.0005,5.001

`issues.csv`:

    sample_id,source,reason
    S-007,data/day2.csv,invalid numeric value 'broken'
    S-013,data/day3.csv,invalid numeric value 'bad'

`FT-01` counts four samples: `S-001`, `S-002` and `S-006` from the `OK` rows plus
`S-011` (`4.125`, `VALID`), with the `S-002` copy in `data/day2.csv` merged
away — mean `(1.00 + 1.01 + 3.205 + 4.125) / 4 = 2.335`. `FT-02` counts
`-2.005`, `7.25`, `1.999` and `-4.50` (its `S-008` row is identical in
`data/day2.csv` and `data/day3.csv`), giving `2.744 / 4 = 0.686`. `FT-03` now
has one counted sample (`S-009`, `0.75`). `FT-04` has one counted sample,
`5.0005`, whose mean rounds to `5.001` while `min` and `max` keep the exact
value; its `OFFLINE` row is dropped. The two bad values are reported as issues
because their status is valid but their value is not a number.

### Empty input

    sample_id,device_id,value,status

With `--input empty.csv --output empty_summary.csv`, `empty_summary.csv`
contains just:

    device_id,count,min,max,mean

## Troubleshooting

- `usage: sample_report.py ... error: the following arguments are required` —
  pass `--input` (at least once) and `--output`.
- `error: conflicting records for sample_id ...` — two files disagree about one
  sample. Reconcile the source systems, or feed the files separately; no output
  was written.
- `FileNotFoundError` — an `--input` path does not exist; check every `--input`
  value.
- A sample seems missing from `count` — check its status against the policy
  (`OK` and `VALID` currently count) and whether `--issues` lists it because its
  value is not a number.