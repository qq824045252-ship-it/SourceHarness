# Change note: first release vs current release

This note audits the report against the release that first shipped the tool and
records how the policy moved since. It is documentation only: the program, the
data files and the other documents are unchanged by this note.

## What "first release" means here

The first release is the version that turned the skeleton into a working report:
one `--input`, one `--output`, per-instrument `count`/`min`/`max`/`mean`, and the
policy of that moment. Its acceptance run is recorded as run 242, validation
event 316 (result `r315`), against tested workspace revision
`280c2ae73a8e0f11f169e1d19464a5041d2409f37f3aea5dbc00811474a2af1e`.

Two snapshots anchor the audit of that release:

| Artifact | Historical snapshot revision | Read result | History events (run 1) |
| -------- | ---------------------------- | ----------- | ---------------------- |
| `docs/report_policy.md` (first-release policy) | `9f56b1086af4edbb40c95e52d8869c47d584ea362136e98738766709d0aedf7e` | `r14` | event 15, event 152 |
| `data/day1.csv` (original samples) | `849b409ad91c2dc040827a6e80dd3b50c43ae93a595c1c1c05b15cfcd7270ec6` | `r35` | event 36, event 150 |

The first-release policy read back, in full, as:

    # Sampling report policy

    - Valid statuses: OK.
    - Compute statistics with decimal arithmetic.
    - Round the mean to 2 decimal places using round half up.
    - Report instruments that have valid numeric samples. With no valid samples, write only the CSV header.
    - Keep all input files unchanged.

## Audit of the WARMUP row

In the original `data/day1.csv` (the snapshot above) the row is the fourth line:

    sample_id,device_id,value,status
    S-001,FT-01,1.00,OK
    S-002,FT-01,1.01,OK
    S-003,FT-02,-2.005,OK
    S-WARM-017,FT-02,812.037,WARMUP
    S-004,FT-02,7.25,VALID
    S-005,FT-03,93.3,OFFLINE

- **sample_id:** `S-WARM-017`
- **Original value:** `812.037`
- **Instrument:** `FT-02`
- **Status:** `WARMUP`

**Why it was excluded.** The first-release policy declared `Valid statuses: OK.`
so the status filter ran before any value handling: `812.037` is a perfectly
parseable decimal, but `WARMUP` is not `OK`, so the row was dropped as an invalid
status. It was therefore never a data defect — nothing about the value is
malformed — and in the first release, which had no `--issues` report, it left no
trace at all.

Consequences at the time: `FT-02`'s first-release line was computed from `-2.005`
alone, i.e. count 1, `min` `-2.005`, `max` `-2.005`, mean `-2.005` rounded half
up to 2 places = `-2.01`. Had `S-WARM-017` counted, that number would have been
`(−2.005 + 812.037) / 2`, roughly `405.016`.

**Status today.** `S-WARM-017` is *still* excluded, for the same reason: the
current policy accepts `OK` and `VALID`, and `WARMUP` is neither. If `WARMUP`
were ever added to the valid statuses, this row would start counting
immediately, so it is worth keeping in mind when the policy is next edited. The
row itself is untouched in `data/day1.csv`.

## Valid statuses and mean precision: first vs current

| Aspect | First release | Current release |
| ------ | ------------- | --------------- |
| Valid statuses | `OK` only (policy snapshot `9f56b108…`, `r14`, events 15 and 152) | `OK` and `VALID` (current policy revision `21f1a79fc405033ec4c5edc1cc6cb858ad512f48120c4e9dc33b29460a906fee`, result `r246`) |
| Mean precision | 2 decimal places, round half up | 3 decimal places, round half up |
| Implementation | `VALID_STATUS = "OK"`, `MEAN_PLACES = Decimal("0.01")` | `VALID_STATUSES = ("OK", "VALID")`, `MEAN_PLACES = Decimal("0.001")` |
| Inputs | one file per run (`--input` once) | repeatable `--input`, de-duplication of identical `sample_id` records, conflict error on differing contents |
| Skipped values | silent | optional `--issues` CSV with `sample_id`, `source`, `reason` |
| Unchanged | decimal arithmetic, header-only output when nothing is valid, input files never modified | same |

Effects of the policy change on the documented example values:

- `FT-01` from `data/day1.csv` keeps count 2 and `min` `1.00` / `max` `1.01`, but
  its mean is now shown to three places: `1.005` (was `1.01`).
- `FT-02` from `data/day1.csv` gained a counted sample: `7.25` has status
  `VALID`, which the first release ignored. Count 2, mean `(−2.005 + 7.25)/2 =
  2.6225 → 2.623` (was count 1, `-2.01`).
- `S-004` (`data/day1.csv`), `S-008` (`data/day2.csv` / `data/day3.csv`),
  `S-011` and `S-014` are the `VALID` rows that the first release would have
  dropped; they now count. `S-006` (`data/day2.csv`, `3.205`) is `OK`, so it
  counted in both releases.

## Supporting evidence

- First-release policy text: `docs/report_policy.md` snapshot `9f56b108…`,
  read result `r14`, history events 15 and 152 (run 1) — quoted above.
- First-release `data/day1.csv` content including `S-WARM-017,FT-02,812.037,WARMUP`:
  snapshot `849b409a…`, read result `r35`, history events 36 and 150 (run 1).
- First release accepted: run 242, validation event 316, result `r315`, tested
  workspace revision `280c2ae7…`.
- Current policy (`OK` and `VALID`, 3 decimal places): revision `21f1a79f…`,
  result `r246`.

Nothing in this note changes the program, the CSV data, `README.md`,
`docs/report_policy.md` or `docs/usage.md`; it only records the comparison.