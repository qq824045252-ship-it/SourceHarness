"""Reading sample CSVs and writing summary CSVs."""

import csv
from decimal import Decimal

#: Columns of the summary report, in order.
SUMMARY_FIELDS = ("device_id", "count", "min", "max", "mean")

#: Columns of the optional issues report, in order.
ISSUE_FIELDS = ("sample_id", "source", "reason")


def read_rows(path):
    with open(path, newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def _format_value(value):
    """Render a cell; decimals keep their digits and avoid exponent notation."""
    if isinstance(value, Decimal):
        return format(value, "f")
    return str(value)


def write_issues(path, issues):
    """Write skipped rows to ``path``, header only when there are none."""
    with open(path, "w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(ISSUE_FIELDS)
        for issue in issues:
            writer.writerow([_format_value(issue[field]) for field in ISSUE_FIELDS])


def write_summary(path, summaries):
    """Write ``summaries`` to ``path`` as CSV, header only when there are none."""
    with open(path, "w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(SUMMARY_FIELDS)
        for summary in summaries:
            writer.writerow(
                [_format_value(summary[field]) for field in SUMMARY_FIELDS]
            )
