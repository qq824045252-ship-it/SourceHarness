"""Aggregate instrument samples into per-device statistics.

Business rules come from docs/report_policy.md: ``OK`` and ``VALID`` samples
count, all arithmetic is done with :class:`decimal.Decimal`, and the mean is
rounded to three decimal places using round half up.
"""

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

#: Statuses that contribute to the report (see docs/report_policy.md).
VALID_STATUSES = ("OK", "VALID")

#: Mean precision; the policy, not the code, decides how many places.
MEAN_PLACES = Decimal("0.001")


def parse_value(raw):
    """Return ``raw`` as a Decimal, or ``None`` when it is not a number."""
    if raw is None:
        return None
    text = raw.strip()
    if not text:
        return None
    try:
        value = Decimal(text)
    except InvalidOperation:
        return None
    if not value.is_finite():
        return None
    return value


def iter_valid_samples(rows):
    """Yield ``(device_id, value)`` for every valid numeric sample in ``rows``."""
    for row in rows:
        device_id = (row.get("device_id") or "").strip()
        status = (row.get("status") or "").strip()
        if not device_id or status not in VALID_STATUSES:
            continue
        value = parse_value(row.get("value"))
        if value is None:
            continue
        yield device_id, value


def summarize(rows):
    """Return per-device statistics in order of first appearance.

    Each entry is a dict with ``device_id``, ``count``, ``min``, ``max`` and
    ``mean``. Devices without any valid numeric sample are omitted, so an input
    with no valid samples yields an empty list.
    """
    totals = {}
    for device_id, value in iter_valid_samples(rows):
        entry = totals.get(device_id)
        if entry is None:
            totals[device_id] = {
                "device_id": device_id,
                "count": 1,
                "min": value,
                "max": value,
                "total": value,
            }
        else:
            entry["count"] += 1
            entry["total"] += value
            if value < entry["min"]:
                entry["min"] = value
            if value > entry["max"]:
                entry["max"] = value

    summaries = []
    for entry in totals.values():
        mean = (entry["total"] / entry["count"]).quantize(
            MEAN_PLACES, rounding=ROUND_HALF_UP
        )
        summaries.append(
            {
                "device_id": entry["device_id"],
                "count": entry["count"],
                "min": entry["min"],
                "max": entry["max"],
                "mean": mean,
            }
        )
    return summaries