"""Combine sample CSVs: merge duplicates, detect conflicts, collect issues.

The policy in docs/report_policy.md still decides what is counted: only samples
with a valid status and a numeric value take part in the report. This module
decides which rows reach that rule:

* the same ``sample_id`` seen twice with identical contents is counted once,
* the same ``sample_id`` seen with different contents is an error,
* a row with a valid status but an unusable value is skipped and recorded as an
  issue so the operator can see it.
"""

from reporting.csv_io import read_rows
from reporting.summary import VALID_STATUSES, parse_value

#: Fields that define the content of a sample record.
RECORD_FIELDS = ("device_id", "value", "status")

REASON_EMPTY_VALUE = "empty value"
REASON_INVALID_VALUE = "invalid numeric value"
REASON_MISSING_DEVICE = "missing device_id"


class ConflictError(Exception):
    """Raised when one ``sample_id`` is used for records with different contents."""


def _clean(row, field):
    return (row.get(field) or "").strip()


def _describe(row):
    return ", ".join(
        "{}={!r}".format(field, _clean(row, field)) for field in RECORD_FIELDS
    )


def _issue(sample_id, source, reason):
    return {"sample_id": sample_id, "source": source, "reason": reason}


def merge_records(sources):
    """Return ``(records, duplicates)`` from the given CSV paths.

    ``records`` holds ``(row, source, sample_id)`` in first-seen order. A repeat
    of an identical record is dropped and counted in ``duplicates``; a repeat of
    a ``sample_id`` with different contents raises :class:`ConflictError`.
    """
    records = []
    seen = {}
    duplicates = 0
    for path in sources:
        for row in read_rows(path):
            sample_id = _clean(row, "sample_id")
            content = tuple(_clean(row, field) for field in RECORD_FIELDS)
            if not sample_id:
                # No identity to merge on, so the row stands on its own.
                records.append((row, path, sample_id))
                continue
            previous = seen.get(sample_id)
            if previous is None:
                seen[sample_id] = (content, path, row)
                records.append((row, path, sample_id))
            elif previous[0] == content:
                duplicates += 1
            else:
                raise ConflictError(
                    "conflicting records for sample_id {!r}: {} has {} but {} has "
                    "{}".format(
                        sample_id,
                        previous[1],
                        _describe(previous[2]),
                        path,
                        _describe(row),
                    )
                )
    return records, duplicates


def load_samples(sources):
    """Return ``(rows, issues, duplicates)`` for the given CSV paths.

    ``rows`` are the unique records that pass the status and value rules and can
    feed :func:`reporting.summary.summarize`. ``issues`` describes the skipped
    rows as ``sample_id``/``source``/``reason`` dicts, in input order.
    """
    records, duplicates = merge_records(sources)
    rows = []
    issues = []
    for row, path, sample_id in records:
        if _clean(row, "status") not in VALID_STATUSES:
            continue
        raw_value = _clean(row, "value")
        if not raw_value:
            issues.append(_issue(sample_id, path, REASON_EMPTY_VALUE))
        elif parse_value(raw_value) is None:
            issues.append(
                _issue(sample_id, path, "{} {!r}".format(REASON_INVALID_VALUE, raw_value))
            )
        elif not _clean(row, "device_id"):
            issues.append(_issue(sample_id, path, REASON_MISSING_DEVICE))
        else:
            rows.append(row)
    return rows, issues, duplicates