"""Command line entry point for the instrument sampling report."""

import argparse
import sys

from reporting.csv_io import write_issues, write_summary
from reporting.inputs import ConflictError, load_samples
from reporting.summary import summarize


def build_parser():
    parser = argparse.ArgumentParser(
        description=(
            "Summarize instrument samples into a per-device CSV report. "
            "Repeat --input to combine several files."
        )
    )
    parser.add_argument(
        "--input",
        required=True,
        action="append",
        metavar="CSV",
        help=(
            "sample CSV to read (columns: sample_id,device_id,value,status); "
            "repeat the flag to combine several files"
        ),
    )
    parser.add_argument(
        "--output",
        required=True,
        help="summary CSV to write (columns: device_id,count,min,max,mean)",
    )
    parser.add_argument(
        "--issues",
        default=None,
        metavar="CSV",
        help=(
            "optional CSV listing skipped samples "
            "(columns: sample_id,source,reason)"
        ),
    )
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        rows, issues, duplicates = load_samples(args.input)
    except ConflictError as exc:
        print("error: {}".format(exc), file=sys.stderr)
        return 2

    summaries = summarize(rows)
    write_summary(args.output, summaries)
    if args.issues:
        write_issues(args.issues, issues)

    print(
        "Read {} sample(s) from {} file(s): {} duplicate(s), {} issue(s)".format(
            len(rows), len(args.input), duplicates, len(issues)
        )
    )
    print("Wrote {} instrument(s) to {}".format(len(summaries), args.output))
    if args.issues:
        print("Wrote {} issue(s) to {}".format(len(issues), args.issues))
    return 0


if __name__ == "__main__":
    sys.exit(main())