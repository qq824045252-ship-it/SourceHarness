# Instrument sampling reports

The input examples are in data/day1.csv, data/day2.csv and data/day3.csv. See
docs/report_policy.md for the business rules and docs/usage.md for inputs,
output and rules in detail.

    python sample_report.py --input data/day1.csv --output summary.csv

The summary CSV uses the columns device_id,count,min,max,mean, one row per
instrument that has at least one counted (valid status, numeric) sample. Which
statuses count, and how far the mean is rounded, are decided by
docs/report_policy.md:

    device_id,count,min,max,mean
    FT-01,2,1.00,1.01,1.005
    FT-02,2,-2.005,7.25,2.623

Repeat `--input` to combine several files. A `sample_id` that repeats with
identical contents is counted once; a `sample_id` with conflicting contents is
reported as an error. Add `--issues` to record samples that were skipped
because of a bad value:

    python sample_report.py --input data/day1.csv --input data/day2.csv --input data/day3.csv --output combined.csv --issues issues.csv

combined.csv:

    device_id,count,min,max,mean
    FT-01,4,1.00,4.125,2.335
    FT-02,4,-4.50,7.25,0.686
    FT-03,1,0.75,0.75,0.750
    FT-04,1,5.0005,5.0005,5.001

issues.csv:

    sample_id,source,reason
    S-007,data/day2.csv,invalid numeric value 'broken'
    S-013,data/day3.csv,invalid numeric value 'bad'

See docs/usage.md for the full column reference, the de-duplication and conflict
rules, the rounding and validity rules, and empty-input behaviour.

> Maintainer note: Keep degree-of-precision decisions in the report policy.