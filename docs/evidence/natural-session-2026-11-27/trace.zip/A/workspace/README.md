# Instrument sampling reports

Turn raw instrument sample CSVs into a per-instrument summary: how many valid
samples each instrument produced, plus their minimum, maximum and mean.

## Runnable example

    python sample_report.py --input data/day1.csv --output summary.csv

`--input` is the raw sample CSV to read (never modified) and `--output` is the
summary CSV to write. The sample inputs are `data/day1.csv`, `data/day2.csv` and
`data/day3.csv`.

Running the command above on `data/day1.csv` writes:

    device_id,count,min,max,mean
    FT-01,2,1.00,1.01,1.005
    FT-02,2,-2.005,7.25,2.623

## Combining several days

Repeat `--input` to process files together, and add `--issues` for a report of
skipped samples:

    python sample_report.py --input data/day1.csv --input data/day2.csv --input data/day3.csv --output summary.csv --issues issues.csv

That writes:

    device_id,count,min,max,mean
    FT-01,4,1.00,4.125,2.335
    FT-02,4,-4.50,7.25,0.686
    FT-03,1,0.75,0.75,0.750
    FT-04,1,5.0005,5.0005,5.001

and `issues.csv`:

    sample_id,reason
    S-007,non-numeric value: 'broken'
    S-013,non-numeric value: 'bad'

The summary CSV always uses the columns `device_id,count,min,max,mean`, sorted
by `device_id`. Only `OK` and `VALID` samples with a numeric value count;
statistics use decimal arithmetic and the mean is rounded as the report policy
requires. A `sample_id` seen in several inputs with identical contents (such as
`S-002` and `S-008`) is counted once; the same `sample_id` with different
contents is a hard error (exit code 2) naming both files and the differing
columns. Instruments with no valid sample are left out, and inputs with no valid
samples yield a header-only file.

See [docs/usage.md](docs/usage.md) for the full input/output reference and
[docs/report_policy.md](docs/report_policy.md) for the business rules.

> Maintainer note: Keep degree-of-precision decisions in the report policy.