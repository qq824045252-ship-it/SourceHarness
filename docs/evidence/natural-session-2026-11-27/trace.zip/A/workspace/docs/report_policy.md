# Sampling report policy

- Valid statuses: OK and VALID.
- Compute statistics with decimal arithmetic.
- Round the mean to 3 decimal places using round half up.
- Report instruments that have valid numeric samples. With no valid samples, write only the CSV header.
- Keep all input files unchanged.
