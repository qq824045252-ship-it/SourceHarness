# Usage

`sample_report.py` reads one or more raw instrument sample CSVs and writes a
per-instrument summary CSV. All business rules come from
[report_policy.md](report_policy.md), which is the single source of truth for
which statuses are valid and to how many decimals the mean is rounded.

## Command

```
python sample_report.py --input data/day1.csv --output summary.csv
```

| Option | Meaning |
| --- | --- |
| `--input PATH` | Raw sample CSV to read. Required. **Repeat the option to combine several files**; a single `--input` works exactly as in the first release. |
| `--output PATH` | Summary CSV to create/overwrite. Required. Use a path other than the inputs. |
| `--issues PATH` | Optional CSV listing every skipped sample with the reason. Written only when requested. |

Combine all three days into one report:

```
python sample_report.py --input data/day1.csv --input data/day2.csv \
    --input data/day3.csv --output summary.csv --issues issues.csv
```

Inputs are read in the order given and treated as one dataset, so the rules
below apply to the union of their rows. The command prints a short status line,
for example:

```
Wrote 4 instrument row(s) to summary.csv
Skipped 2 sample(s) with invalid values; see issues.csv
```

Exit codes: `0` success, `2` conflicting records, `1` an input file could not be
read. Nothing is written when the command fails with `2` or `1`.

## Input format

A header row with at least these columns (extra columns are ignored):

| Column | Used for |
| --- | --- |
| `sample_id` | Identity of the reading. Two rows with the same `sample_id` are the same sample. |
| `device_id` | Instrument the sample is grouped under. |
| `value` | Sample reading, parsed with exact decimal arithmetic. |
| `status` | Sample status. Validity is defined by the report policy: currently `OK` and `VALID`. |

Example (`data/day1.csv`):

```
sample_id,device_id,value,status
S-001,FT-01,1.00,OK
S-002,FT-01,1.01,OK
S-003,FT-02,-2.005,OK
S-WARM-017,FT-02,812.037,WARMUP
S-004,FT-02,7.25,VALID
S-005,FT-03,93.3,OFFLINE
```

## Output format

A CSV with exactly this header, one row per reported instrument, sorted by
`device_id`:

```
device_id,count,min,max,mean
```

| Column | Meaning |
| --- | --- |
| `device_id` | Instrument identifier. |
| `count` | Number of valid numeric samples for that instrument, after de-duplication. |
| `min` | Smallest valid value, printed exactly as parsed (input precision kept). |
| `max` | Largest valid value, printed exactly as parsed (input precision kept). |
| `mean` | Arithmetic mean of the valid values, rounded half up to 3 decimal places (the precision fixed by the report policy): `1.005` stays `1.005`, `2.6225` -> `2.623`, `5.0005` -> `5.001`. |

`data/day1.csv` alone produces:

```
device_id,count,min,max,mean
FT-01,2,1.00,1.01,1.005
FT-02,2,-2.005,7.25,2.623
```

`data/day1.csv`, `data/day2.csv` and `data/day3.csv` together produce:

```
device_id,count,min,max,mean
FT-01,4,1.00,4.125,2.335
FT-02,4,-4.50,7.25,0.686
FT-03,1,0.75,0.75,0.750
FT-04,1,5.0005,5.0005,5.001
```

`S-002` appears in both day 1 and day 2, and `S-008` in both day 2 and day 3,
with identical contents each time; both are counted once. That is why `FT-01`
has 4 samples rather than 5, with mean `(1.00 + 1.01 + 3.205 + 4.125) / 4 =
2.335`.

## Issues report

With `--issues issues.csv`, every valid-status sample whose `value` is not a
number is written there instead of being silently dropped:

```
sample_id,reason
S-007,non-numeric value: 'broken'
S-013,non-numeric value: 'bad'
```

The issues file always has the header `sample_id,reason`, and is written with
only that header when nothing was skipped. Reasons are `non-numeric value: '...'`
for unparseable text and `missing value` for a blank cell.

## Rules applied

1. **Validity.** A sample counts only when its `status` is valid per the report
   policy (`OK` or `VALID`) *and* its `value` is a number. `WARMUP`, `OFFLINE`,
   blank or unknown statuses are skipped, and are not reported as issues,
   because the status already excludes them.
2. **Duplicate samples.** Rows sharing a `sample_id` with identical contents
   (for example `S-002` in days 1 and 2, or `S-008` in days 2 and 3) are the same
   sample and are counted once, however many inputs contain them.
3. **Conflicting samples.** Rows sharing a `sample_id` but differing in any
   field are an error; the report is abandoned and the conflict is described on
   stderr with both source files and the differing columns:

   ```
   error: sample_id 'S-011' has conflicting records (differs in: value)
     data/day1.csv: sample_id='S-011', device_id='FT-01', value='4.125', status='VALID'
     data/day3.csv: sample_id='S-011', device_id='FT-01', value='4.130', status='VALID'
   ```

4. **Bad numeric values.** A sample with a valid status but no usable number is
   skipped and, when `--issues` is given, listed with its `sample_id` and reason.
   In the sample data, `S-007` has value `broken` and `S-013` has value `bad`.
5. **Decimal arithmetic.** Values are parsed as `decimal.Decimal`, so binary
   floating point artefacts (`0.1 + 0.2`) never affect `min`, `max` or `mean`.
6. **Mean rounding.** The mean is rounded half up to 3 decimal places, the
   precision set by the report policy, so ties round away from zero: `2.6225` ->
   `2.623`, `5.0005` -> `5.001`, and `-2.005` stays `-2.005`.
7. **Reported instruments.** Only instruments with at least one valid numeric
   sample appear. `FT-03` in `data/day1.csv` has only an `OFFLINE` sample and is
   therefore absent when day 1 is processed alone, but appears once day 2 (which
   holds `S-009`) is included. `FT-04`'s `OFFLINE` reading `S-015` is ignored.
8. **No valid samples.** If nothing in the inputs is valid, the summary contains
   only the header line `device_id,count,min,max,mean`.
9. **Inputs untouched.** Raw files under `data/` and the policy document are read
   only; results go to `--output` and `--issues`.

## Examples

```sh
# first-release single-file usage still works
python sample_report.py --input data/day1.csv --output summary_day1.csv

# combine all days, and capture skipped samples
python sample_report.py --input data/day1.csv --input data/day2.csv \
    --input data/day3.csv --output summary.csv --issues issues.csv
```