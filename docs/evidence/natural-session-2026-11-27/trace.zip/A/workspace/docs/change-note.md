# Change note: first release vs current release

Audit of the first release of the sampling report, compared with the current
release. This note is documentation only: the program, the raw inputs and the
existing docs were not modified to produce it. 3-decimal precision and the
wider status set come from `docs/report_policy.md`, which remains the source of
truth.

## 1. The WARMUP row in the original `data/day1.csv`

| Field | Original value |
| --- | --- |
| `sample_id` | `S-WARM-017` |
| `device_id` | `FT-02` |
| `value` (original text) | `812.037` |
| `status` | `WARMUP` |

Original file content (7 lines, 175 bytes), line 4:

```
sample_id,device_id,value,status
S-001,FT-01,1.00,OK
S-002,FT-01,1.01,OK
S-003,FT-02,-2.005,OK
S-WARM-017,FT-02,812.037,WARMUP
S-004,FT-02,7.25,VALID
S-005,FT-03,93.3,OFFLINE
```

**Why it was excluded.** The first release applied the status gate *before*
looking at the value. The policy in force then read `Valid statuses: OK.`, so
only rows whose `status` was exactly `OK` were eligible; `WARMUP` was dropped by
the `!= VALID_STATUS` test in `reporting/summary.py` and never reached
`parse_value`. This was a status exclusion, not a parse failure: `812.037` is a
perfectly valid decimal, so the row was silently skipped and (in the first
release) nothing was reported about it. The same is true today — the current
policy accepts `OK` and `VALID` only, so `S-WARM-017` is still excluded, and
because it is not a valid status it never appears in the `--issues` report
either (that report covers valid-status rows with unusable values).

**Why it matters.** Had the row been counted, it would have dominated `FT-02`:
`min`/`max` would have stretched to include `812.037` against otherwise
single-digit readings (the next largest is `7.25`).

**Supporting snapshot.** `data/day1.csv` @ revision
`849b409ad91c2dc040827a6e80dd3b50c43ae93a595c1c1c05b15cfcd7270ec6`, captured by
`read` in **run 1, event 32** (seq 32, operation `1.2.7`), immutable result
reference **`r31`** (lines 1-7, `total_bytes` 175).

> Note: the current `data/day1.csv` no longer carries this row — it is now 143
> bytes at revision `31558f9f51904d4e2d426d8a81ab9d58f4d569b0d0e73ad294762c826d8d7e93`
> (read in this run, result `r266`). The WARMUP record above is therefore
> recoverable only from the historical snapshot `r31`.

## 2. First release vs current release

| Dimension | First release | Current release |
| --- | --- | --- |
| Valid statuses | `OK` only | `OK` and `VALID` |
| Mean precision | 2 decimal places, round half up | 3 decimal places, round half up |
| Code constant | `VALID_STATUS = "OK"` | `VALID_STATUSES = ("OK", "VALID")` |
| Rounding quantum | `MEAN_QUANTUM = Decimal("0.01")` | `MEAN_QUANTUM = Decimal("0.001")` |
| Status test | `status != VALID_STATUS` | `status not in VALID_STATUSES` |
| Policy text | `- Valid statuses: OK.` / `- Round the mean to 2 decimal places using round half up.` | `- Valid statuses: OK and VALID.` / `- Round the mean to 3 decimal places using round half up.` |

### Observed effect on `data/day1.csv`

| Instrument | First release (OK only, 2 dp) | Current release (OK + VALID, 3 dp) |
| --- | --- | --- |
| `FT-01` | count 2, min `1.00`, max `1.01`, mean `1.01` | count 2, min `1.00`, max `1.01`, mean `1.005` |
| `FT-02` | count 1, min `-2.005`, max `-2.005`, mean `-2.01` | count 2, min `-2.005`, max `7.25`, mean `2.623` |
| `FT-03` | not reported (`OFFLINE` only) | not reported (`OFFLINE` only) |

Two independent changes are visible here. Widening the status set pulls the
`VALID` row `S-004` (`FT-02`, `7.25`) into `FT-02`, which doubles its count and
moves its mean from `-2.01` to `2.623`. Extending the mean to 3 decimals changes
`FT-01`'s mean from `1.01` to `1.005`: the first release rounded the exact mean
`1.005` at the second decimal, the current release prints it unrounded at the
third. `S-WARM-017` is excluded in both releases.

## 3. Evidence index

| Fact | Source | Revision | Run / event | Result ref |
| --- | --- | --- | --- | --- |
| Original `data/day1.csv` incl. `S-WARM-017` | `read data/day1.csv` | `849b409a…d7270ec6` | run 1, event 32 (seq 32), op `1.2.7` | `r31` |
| Original policy: `OK` only, mean 2 dp | `read docs/report_policy.md` | `9f56b108…edf7e` | run 1, event 15 (seq 15), op `1.2.1` | `r14` |
| First-release code: `VALID_STATUS = "OK"`, `MEAN_QUANTUM = 0.01` | `write reporting/summary.py` (diff) | before `8fc27f3d…` (stub) → after `0baec4fe…` | run 1, event 43 (seq 43), op `1.3.1` | diff `r41` |
| Current policy: `OK and VALID`, mean 3 dp | `read docs/report_policy.md` | `21f1a79f…906fee` | run 171, event 176 (seq 176), op `171.1.1` | `r175` |
| Current code: `VALID_STATUSES`, `MEAN_QUANTUM = 0.001` | `edit reporting/summary.py` (diff) | before `0baec4fe…` → after `715a16a9…` | run 171, event 203 (seq 203), op `171.4.1` | diff `r201` |
| Current `data/day1.csv` without the WARMUP row | `read data/day1.csv` | `31558f9f…d8d7e93` | this run | `r266` |
| Current release acceptance pass | `validate acceptance` | workspace `50cbf869…1f1a3a` | run 171, validation event 258 | `r257` |

Line-level anchors for the original row: `data/day1.csv` line 4 of 7 in `r31`;
the first-release status gate is `valid_samples()` in the `r41` diff; the
current gate is `valid_samples()` in the `r201` diff.

## 4. Scope and method

* The WARMUP record was read from the immutable snapshot `r31` rather than from
  the live file, because the live `data/day1.csv` was subsequently reduced to
  143 bytes and no longer contains `S-WARM-017`.
* The first-release policy was read from snapshot `r14`; the current policy from
  `r175`.
* Both releases' code behavior was confirmed against the diffs `r41` and `r201`,
  which show the exact constants and the status test on either side of the
  change.
* No program, data or policy file was edited for this audit; `docs/change-note.md`
  is the only addition.