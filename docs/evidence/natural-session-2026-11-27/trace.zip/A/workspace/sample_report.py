"""Command line entry point for the instrument sampling report."""

import argparse
import sys

from reporting.csv_io import write_issues, write_summary
from reporting.records import SampleConflictError, collect
from reporting.summary import summarize


def build_parser():
    parser = argparse.ArgumentParser(
        description="Summarize instrument samples from one or more CSV files"
    )
    parser.add_argument(
        "--input",
        required=True,
        action="append",
        dest="inputs",
        metavar="PATH",
        help="sample CSV to read; repeat the option to combine several files",
    )
    parser.add_argument("--output", required=True, help="summary CSV to write")
    parser.add_argument(
        "--issues",
        metavar="PATH",
        help="optional CSV listing skipped samples with the reason",
    )
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)

    try:
        rows, issues = collect(args.inputs)
    except SampleConflictError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    except OSError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    report = summarize(rows)
    write_summary(args.output, report)

    print(f"Wrote {len(report)} instrument row(s) to {args.output}")
    if issues:
        where = f"; see {args.issues}" if args.issues else ""
        print(f"Skipped {len(issues)} sample(s) with invalid values{where}")
    if args.issues:
        write_issues(args.issues, issues)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())