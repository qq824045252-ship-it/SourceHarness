"""CSV reading and writing helpers.

Input files are only ever opened for reading; the summary and the optional
issues report are written to separate paths supplied on the command line.
"""

import csv

SUMMARY_FIELDS = ("device_id", "count", "min", "max", "mean")
ISSUE_FIELDS = ("sample_id", "reason")


def read_rows(path):
    with open(path, newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def write_summary(path, rows):
    """Write summary rows with the policy header, even when ``rows`` is empty."""
    with open(path, "w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(
            stream, fieldnames=SUMMARY_FIELDS, extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(rows)


def write_issues(path, rows):
    """Write skipped samples with the issues header, even when ``rows`` is empty."""
    with open(path, "w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(
            stream, fieldnames=ISSUE_FIELDS, extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(rows)
