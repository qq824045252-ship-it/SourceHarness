"""Instrument sampling reports."""
