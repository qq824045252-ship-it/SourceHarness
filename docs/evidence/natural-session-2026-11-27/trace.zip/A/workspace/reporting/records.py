"""Collect raw sample records from one or more input files.

Adds the multi-file rules on top of ``docs/report_policy.md``:

* a record is identified by its ``sample_id``;
* byte-for-byte identical copies of the same ``sample_id`` (for example a
  sample repeated in two day files) are counted exactly once;
* two records sharing a ``sample_id`` but differing in any field are a hard
  error, because there is no way to tell which copy is correct;
* a row whose ``status`` is neither ``OK`` nor ``VALID`` is simply not valid
  and is dropped silently, but a valid-status row whose ``value`` is not a
  number is skipped *and* reported as an issue.

Input files are only ever opened for reading.
"""

from .csv_io import read_rows
from .summary import VALID_STATUSES, parse_value

FIELD_ORDER = ("sample_id", "device_id", "value", "status")


class SampleConflictError(ValueError):
    """Raised when one ``sample_id`` carries two different records."""


def fields_of(row):
    """Normalize a CSV row to a ``{column: text}`` mapping."""
    return {
        str(key): "" if value is None else str(value)
        for key, value in row.items()
        if key is not None
    }


def describe(fields):
    """Render a record as ``column='value', ...`` for error messages."""
    names = [name for name in FIELD_ORDER if name in fields]
    names += sorted(name for name in fields if name not in FIELD_ORDER)
    return ", ".join(f"{name}={fields[name]!r}" for name in names)


def differing(a, b):
    """Return the sorted field names on which two records disagree."""
    return sorted(
        name for name in set(a) | set(b) if a.get(name) != b.get(name)
    )


def issue_reason(raw):
    """Explain why a valid-status sample was skipped."""
    if raw is None or not raw.strip():
        return "missing value"
    return f"non-numeric value: {raw.strip()!r}"


def collect(paths):
    """Return ``(valid_rows, issues)`` for the given input files.

    ``valid_rows`` holds one dict per distinct valid sample, in first-seen
    order; ``issues`` holds ``{"sample_id": ..., "reason": ...}`` entries for
    ``OK``/``VALID`` rows whose value could not be parsed. Raises
    :class:`SampleConflictError` when two records disagree.
    """
    records = {}
    origins = {}
    order = []

    for path in paths:
        for row in read_rows(path):
            fields = fields_of(row)
            sample_id = fields.get("sample_id", "").strip()
            if not sample_id:
                raise SampleConflictError(
                    f"record without a sample_id in {path}: {describe(fields)}"
                )

            seen = records.get(sample_id)
            if seen is None:
                records[sample_id] = fields
                origins[sample_id] = path
                order.append(sample_id)
            elif seen != fields:
                changed = ", ".join(differing(seen, fields))
                raise SampleConflictError(
                    f"sample_id {sample_id!r} has conflicting records "
                    f"(differs in: {changed})\n"
                    f"  {origins[sample_id]}: {describe(seen)}\n"
                    f"  {path}: {describe(fields)}"
                )

    valid = []
    issues = []
    for sample_id in order:
        fields = records[sample_id]
        if fields.get("status", "").strip() not in VALID_STATUSES:
            continue
        if parse_value(fields.get("value")) is None:
            issues.append(
                {"sample_id": sample_id, "reason": issue_reason(fields.get("value"))}
            )
            continue
        valid.append(fields)

    return valid, issues