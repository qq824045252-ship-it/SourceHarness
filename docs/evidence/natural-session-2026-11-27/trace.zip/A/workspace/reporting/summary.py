"""Aggregate instrument samples into report rows.

Implements the rules in docs/report_policy.md:

* only rows whose ``status`` is ``OK`` or ``VALID`` are valid;
* a valid row must also carry a numeric ``value``;
* all arithmetic uses :class:`decimal.Decimal`;
* the mean is rounded to 3 decimal places with round-half-up;
* instruments without a single valid numeric sample are not reported.
"""

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

VALID_STATUSES = ("OK", "VALID")
MEAN_QUANTUM = Decimal("0.001")


def parse_value(raw):
    """Return ``raw`` as a finite Decimal, or None when it is not a number."""
    if raw is None:
        return None
    text = raw.strip()
    if not text:
        return None
    try:
        value = Decimal(text)
    except (InvalidOperation, ValueError):
        return None
    return value if value.is_finite() else None


def valid_samples(rows):
    """Yield ``(device_id, value)`` pairs for every valid numeric sample."""
    for row in rows:
        if (row.get("status") or "").strip() not in VALID_STATUSES:
            continue
        value = parse_value(row.get("value"))
        if value is None:
            continue
        yield (row.get("device_id") or "").strip(), value


def format_decimal(value):
    """Render a Decimal without exponent notation, keeping its precision."""
    return format(value, "f")


def summarize(rows):
    """Return one report row per instrument that has valid numeric samples.

    Rows are ordered by ``device_id``; an empty list means the input held no
    valid samples and only the CSV header should be written.
    """
    stats = {}
    for device_id, value in valid_samples(rows):
        entry = stats.get(device_id)
        if entry is None:
            entry = stats[device_id] = {
                "count": 0,
                "min": value,
                "max": value,
                "total": Decimal(0),
            }
        entry["count"] += 1
        entry["min"] = min(entry["min"], value)
        entry["max"] = max(entry["max"], value)
        entry["total"] += value

    report = []
    for device_id in sorted(stats):
        entry = stats[device_id]
        mean = (entry["total"] / entry["count"]).quantize(
            MEAN_QUANTUM, rounding=ROUND_HALF_UP
        )
        report.append(
            {
                "device_id": device_id,
                "count": entry["count"],
                "min": format_decimal(entry["min"]),
                "max": format_decimal(entry["max"]),
                "mean": format_decimal(mean),
            }
        )
    return report