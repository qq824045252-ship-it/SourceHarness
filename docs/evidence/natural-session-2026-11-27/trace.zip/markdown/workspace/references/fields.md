# Sampling fields

Each sample has an instrument identifier.
