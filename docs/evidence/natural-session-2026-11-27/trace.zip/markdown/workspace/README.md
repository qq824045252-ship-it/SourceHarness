# Operator kit

- [Operator entry](docs/index.md)
- [Start the instrument](guides/start.md)
