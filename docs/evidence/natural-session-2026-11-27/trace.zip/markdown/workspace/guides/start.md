# Start

Follow the station startup sequence.
