# Instrument sampling reports

Build a per-instrument summary CSV (valid sample count, minimum, maximum and mean)
from one or more CSVs of instrument samples.

The input examples are in data/day1.csv, data/day2.csv and data/day3.csv. See
docs/report_policy.md for the business rules and docs/usage.md for the input/output
formats.

## Run

    python sample_report.py --input data/day1.csv --output summary.csv

`--input` is the samples CSV to read and `--output` is the report CSV to write.
The command prints a one-line confirmation, for example:

    Wrote 2 instrument summaries from data/day1.csv to summary.csv

For `data/day1.csv` the generated `summary.csv` is:

    device_id,count,min,max,mean
    FT-01,2,1.00,1.01,1.005
    FT-02,2,-2.005,7.25,2.623

The summary CSV uses the columns device_id,count,min,max,mean. Only samples whose
status is `OK` or `VALID` and whose value is numeric are counted, and an instrument
with no valid samples is left out of the report (with no valid samples at all, the
output file contains just the header row). Value precision follows
docs/report_policy.md.

## Report across all three days

Repeat `--input` to report on several files at once, and add `--issues` to get a
CSV of the samples that were skipped:

    python sample_report.py --input data/day1.csv --input data/day2.csv --input data/day3.csv --output summary.csv --issues issues.csv

That run prints:

    Wrote 4 instrument summaries from 3 input files to summary.csv
    Counted 2 duplicate records once.
    Reported 2 skipped samples in issues.csv

`summary.csv` then contains:

    device_id,count,min,max,mean
    FT-01,4,1.00,4.125,2.335
    FT-02,4,-4.50,7.25,0.686
    FT-03,1,0.75,0.75,0.750
    FT-04,1,5.0005,5.0005,5.001

and `issues.csv` lists the skipped samples with the reason:

    sample_id,reason,input,value
    S-007,invalid_value,data/day2.csv,broken
    S-013,invalid_value,data/day3.csv,bad

`S-002` (day1 and day2) and `S-008` (day2 and day3) appear twice with the same
contents, so each is counted once. If one `sample_id` appears with *different*
contents the run stops with an error and writes no report, for example:

    error: sample_id 'S-002' has conflicting contents between data/day1.csv and data/day2.csv (value '1.01' vs '1.02')
    error: refusing to write summary.csv; fix the conflicting samples and run again

> Maintainer note: Keep degree-of-precision decisions in the report policy.