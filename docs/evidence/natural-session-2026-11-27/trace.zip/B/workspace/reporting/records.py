"""Merge sample records from one or more input CSVs.

Records are identified by ``sample_id``: a record that appears in several inputs
with identical contents is counted once, while one ``sample_id`` carrying
different contents is a hard error.
"""

from reporting.summary import is_valid_status, parse_decimal

ISSUE_COLUMNS = ("sample_id", "reason", "input", "value")

REASON_INVALID_VALUE = "invalid_value"
REASON_MISSING_DEVICE_ID = "missing_device_id"
REASON_MISSING_SAMPLE_ID = "missing_sample_id"


def normalize_fields(row):
    """Return the trimmed text of every column of *row*."""
    fields = {}
    for name, value in (row or {}).items():
        if name is None:
            continue
        fields[name] = value.strip() if isinstance(value, str) else ""
    return fields


def record_identity(fields):
    """Identity of a record: every column name paired with its text."""
    return tuple(sorted(fields.items()))


class ConflictError(Exception):
    """Raised when one sample_id carries different contents."""

    def __init__(self, conflicts):
        self.conflicts = list(conflicts)
        super().__init__(f"{len(self.conflicts)} conflicting sample_id value(s)")


def describe_conflict(conflict):
    """Return a one-line, human readable description of a conflict."""
    first = conflict["first_fields"]
    second = conflict["second_fields"]
    differing = [
        name
        for name in sorted(set(first) | set(second))
        if first.get(name, "") != second.get(name, "")
    ]
    details = "; ".join(
        f"{name} {first.get(name, '')!r} vs {second.get(name, '')!r}"
        for name in differing
    )
    return (
        f"sample_id {conflict['sample_id']!r} has conflicting contents between "
        f"{conflict['first_input']} and {conflict['second_input']} ({details})"
    )


def _issue(sample_id, reason, path, value):
    return {
        "sample_id": sample_id,
        "reason": reason,
        "input": path,
        "value": value,
    }


def merge_records(sources):
    """Merge ``(path, rows)`` sources into valid records.

    Returns ``(records, issues, duplicate_count)``. ``records`` holds only the
    rows with a valid status, a numeric value and a known instrument, in
    first-appearance order. Raises :class:`ConflictError` when the same
    ``sample_id`` shows up with different contents.
    """
    seen = {}
    records = []
    issues = []
    conflicts = []
    duplicate_count = 0

    for path, rows in sources:
        for row in rows:
            fields = normalize_fields(row)
            sample_id = fields.get("sample_id", "")
            identity = record_identity(fields)

            if not sample_id:
                if is_valid_status(fields.get("status")):
                    issues.append(
                        _issue("", REASON_MISSING_SAMPLE_ID, path, fields.get("value", ""))
                    )
                continue

            previous = seen.get(sample_id)
            if previous is not None:
                if previous["identity"] == identity:
                    duplicate_count += 1
                else:
                    conflicts.append(
                        {
                            "sample_id": sample_id,
                            "first_input": previous["input"],
                            "first_fields": previous["fields"],
                            "second_input": path,
                            "second_fields": fields,
                        }
                    )
                continue

            seen[sample_id] = {
                "identity": identity,
                "fields": fields,
                "input": path,
            }

            if not is_valid_status(fields.get("status")):
                continue

            value_text = fields.get("value", "")
            if not fields.get("device_id"):
                issues.append(
                    _issue(sample_id, REASON_MISSING_DEVICE_ID, path, value_text)
                )
                continue
            if parse_decimal(value_text) is None:
                issues.append(_issue(sample_id, REASON_INVALID_VALUE, path, value_text))
                continue

            records.append(row)

    if conflicts:
        raise ConflictError(conflicts)
    return records, issues, duplicate_count