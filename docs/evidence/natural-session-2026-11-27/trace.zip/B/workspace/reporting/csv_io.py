"""CSV input and output helpers for the sampling report."""

import csv

from reporting.records import ISSUE_COLUMNS
from reporting.summary import SUMMARY_COLUMNS


def read_rows(path):
    """Read *path* as a list of dict rows, leaving the file untouched."""
    with open(path, newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def write_summary(path, summaries):
    """Write summary rows to *path*.

    With no summaries only the header is written, as the policy requires.
    """
    with open(path, "w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(
            stream, fieldnames=list(SUMMARY_COLUMNS), lineterminator="\n"
        )
        writer.writeheader()
        for summary in summaries:
            writer.writerow({name: summary[name] for name in SUMMARY_COLUMNS})
    return len(summaries)


def write_issues(path, issues):
    """Write skipped-sample rows to *path*, header only when there are none."""
    with open(path, "w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(
            stream, fieldnames=list(ISSUE_COLUMNS), lineterminator="\n"
        )
        writer.writeheader()
        for issue in issues:
            writer.writerow({name: issue.get(name, "") for name in ISSUE_COLUMNS})
    return len(issues)
