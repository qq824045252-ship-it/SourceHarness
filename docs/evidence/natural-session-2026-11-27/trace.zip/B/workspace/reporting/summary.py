"""Summary statistics for instrument samples (see docs/report_policy.md)."""

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

# Statuses that make a sample count, per docs/report_policy.md.
VALID_STATUSES = ("OK", "VALID")

# The mean precision and rounding mode are set by docs/report_policy.md:
# three decimal places, round half up.
MEAN_QUANTUM = Decimal("0.001")

SUMMARY_COLUMNS = ("device_id", "count", "min", "max", "mean")


def parse_decimal(text):
    """Return *text* as a finite Decimal, or None when it is not a number."""
    if text is None:
        return None
    try:
        value = Decimal(text.strip())
    except (InvalidOperation, AttributeError, ValueError):
        return None
    if not value.is_finite():
        return None
    return value


def is_valid_status(status):
    return (status or "").strip() in VALID_STATUSES


def collect_stats(rows):
    """Return per-device stats for rows with a valid numeric sample.

    Devices are kept in first-appearance order. Instruments without any valid
    numeric sample are simply absent from the result.
    """
    stats = {}
    for row in rows:
        if not is_valid_status(row.get("status")):
            continue
        device_id = (row.get("device_id") or "").strip()
        if not device_id:
            continue
        value = parse_decimal(row.get("value"))
        if value is None:
            continue

        entry = stats.get(device_id)
        if entry is None:
            stats[device_id] = {
                "device_id": device_id,
                "count": 1,
                "min": value,
                "max": value,
                "total": value,
            }
            continue

        entry["count"] += 1
        entry["total"] += value
        if value < entry["min"]:
            entry["min"] = value
        if value > entry["max"]:
            entry["max"] = value
    return list(stats.values())


def format_mean(total, count):
    mean = (total / Decimal(count)).quantize(MEAN_QUANTUM, rounding=ROUND_HALF_UP)
    return format(mean, "f")


def summarize(rows):
    """Return summary rows as plain string dicts ready for CSV output."""
    summaries = []
    for entry in collect_stats(rows):
        summaries.append(
            {
                "device_id": entry["device_id"],
                "count": str(entry["count"]),
                "min": format(entry["min"], "f"),
                "max": format(entry["max"], "f"),
                "mean": format_mean(entry["total"], entry["count"]),
            }
        )
    return summaries
