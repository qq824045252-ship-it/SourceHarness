"""Build an instrument sampling report CSV from one or more samples CSVs."""

import argparse
import sys

from reporting.csv_io import read_rows, write_issues, write_summary
from reporting.records import ConflictError, describe_conflict, merge_records
from reporting.summary import summarize


def build_parser():
    parser = argparse.ArgumentParser(
        description="Summarize instrument samples into a report CSV.",
        epilog="See docs/usage.md for the input format and the report rules.",
    )
    parser.add_argument(
        "--input",
        action="append",
        required=True,
        metavar="PATH",
        help="Samples CSV to read; repeat the option to merge several files",
    )
    parser.add_argument(
        "--output",
        required=True,
        metavar="PATH",
        help="Report CSV to write (columns: device_id,count,min,max,mean)",
    )
    parser.add_argument(
        "--issues",
        metavar="PATH",
        help="Optional CSV listing skipped samples and the reason they were skipped",
    )
    return parser


def describe_inputs(paths):
    if len(paths) == 1:
        return paths[0]
    return f"{len(paths)} input files"


def plural(count, singular):
    return f"{count} {singular}" + ("" if count == 1 else "s")


def main(argv=None):
    args = build_parser().parse_args(argv)

    sources = []
    for path in args.input:
        try:
            rows = read_rows(path)
        except OSError as error:
            print(f"error: cannot read input {path!r}: {error}", file=sys.stderr)
            return 1
        sources.append((path, rows))

    try:
        records, issues, duplicate_count = merge_records(sources)
    except ConflictError as error:
        for conflict in error.conflicts:
            print(f"error: {describe_conflict(conflict)}", file=sys.stderr)
        print(
            f"error: refusing to write {args.output}; "
            "fix the conflicting samples and run again",
            file=sys.stderr,
        )
        return 1

    summaries = summarize(records)

    try:
        count = write_summary(args.output, summaries)
    except OSError as error:
        print(f"error: cannot write output {args.output!r}: {error}", file=sys.stderr)
        return 1

    print(
        f"Wrote {count} instrument summar{'y' if count == 1 else 'ies'} "
        f"from {describe_inputs(args.input)} to {args.output}"
    )
    if duplicate_count:
        print(f"Counted {plural(duplicate_count, 'duplicate record')} once.")

    if args.issues:
        try:
            skipped = write_issues(args.issues, issues)
        except OSError as error:
            print(
                f"error: cannot write issues {args.issues!r}: {error}", file=sys.stderr
            )
            return 1
        print(f"Reported {plural(skipped, 'skipped sample')} in {args.issues}")

    return 0


if __name__ == "__main__":
    sys.exit(main())