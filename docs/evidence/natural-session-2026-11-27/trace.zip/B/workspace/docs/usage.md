# Usage

`sample_report.py` reads one or more CSVs of instrument samples and writes a CSV
report with one row per instrument that has valid samples.

## Command

    python sample_report.py --input data/day1.csv --output summary.csv

| Option | Required | Meaning |
| --- | --- | --- |
| `--input PATH` | yes | Samples CSV to read. Repeat the option to merge several files. Never modified. |
| `--output PATH` | yes | Report CSV to write. Overwritten if it exists. |
| `--issues PATH` | no | Optional CSV listing skipped samples and why they were skipped. |

`--input` may be given once (first release behaviour) or repeated; when it is
repeated the inputs are merged into one report. Order does not matter, because
every input is read completely before the report is built. `--input` also accepts
the same file twice: the repeat is a duplicate and is counted once.

On success the script prints one line per file it wrote and exits with status `0`:

    Wrote 4 instrument summaries from 3 input files to summary.csv
    Counted 2 duplicate records once.
    Reported 2 skipped samples in issues.csv

The duplicate and issues lines only appear when there is something to report. If
an input cannot be read, a report or issues file cannot be written, or two
records conflict, the script prints an `error: ...` message on stderr and exits
with status `1`.

## Input

A header row followed by one row per sample. The columns used are:

| Column | Meaning |
| --- | --- |
| `sample_id` | Sample identifier; the identity used to merge inputs. |
| `device_id` | Instrument identifier; the report is grouped by this value. |
| `value` | The measured value, parsed as a decimal number. |
| `status` | Sample status; `OK` and `VALID` count as valid. |

Anything else in the file is ignored. The example inputs are `data/day1.csv`,
`data/day2.csv` and `data/day3.csv`.

## Merging several inputs

1. Every row of every input is identified by `sample_id`.
2. A `sample_id` seen again with identical contents (every column, compared after
   trimming surrounding whitespace) is a duplicate: it is counted once and
   contributes one sample, not two.
3. A `sample_id` seen again with different contents is a conflict. The run stops
   before anything is written, exits with status `1`, and names the files plus
   the fields that differ, for example:

       error: sample_id 'S-002' has conflicting contents between data/day1.csv and data/day2.csv (value '1.01' vs '1.02')
       error: refusing to write summary.csv; fix the conflicting samples and run again

   Fix or remove the offending row and run again. Conflicts are hard errors so a
   report can never silently mix two versions of one sample.

Because contents are compared as text, `1.0` and `1.00` for the same `sample_id`
count as a conflict; make the duplicated row byte-identical across the inputs.

## Output

A CSV file with the fixed header `device_id,count,min,max,mean`:

| Column | Meaning |
| --- | --- |
| `device_id` | Instrument identifier. |
| `count` | Number of valid samples for that instrument. |
| `min` | Smallest valid value. |
| `max` | Largest valid value. |
| `mean` | Arithmetic mean of the valid values, rounded as specified by `docs/report_policy.md` (currently 3 decimal places, round half up). |

`min` and `max` keep the precision written in the input (so `1.00` stays `1.00`).
Rows appear in the order in which each instrument first shows up in the inputs.

### Example

`data/day1.csv` holds `FT-01` (1.00, 1.01, both `OK`), `FT-02` (-2.005 `OK`, 7.25
`VALID`, plus a `WARMUP` row) and `FT-03` (`OFFLINE` only). Reporting only that file
gives:

    device_id,count,min,max,mean
    FT-01,2,1.00,1.01,1.005
    FT-02,2,-2.005,7.25,2.623

`FT-03` has no valid samples so it is omitted, and `FT-02`'s `WARMUP` row is
ignored. `FT-01`'s mean is exactly 1.005, and `FT-02`'s mean of 2.6225 rounds half
up to 2.623.

Merging all three days adds `S-006` (3.205 `OK`), `S-008` (1.999 `VALID`),
`S-009` (0.75 `OK`), `S-011` (4.125 `VALID`), `S-012` (-4.50 `OK`) and `S-014`
(5.0005 `VALID`). `S-002` and `S-008` are repeated with identical contents, and
`S-007` (`broken`) and `S-013` (`bad`) have no usable number:

    device_id,count,min,max,mean
    FT-01,4,1.00,4.125,2.335
    FT-02,4,-4.50,7.25,0.686
    FT-03,1,0.75,0.75,0.750
    FT-04,1,5.0005,5.0005,5.001

`FT-01` is (1.00 + 1.01 + 3.205 + 4.125) / 4 = 2.335, `FT-02` is
(-2.005 + 7.25 + 1.999 - 4.50) / 4 = 0.686, and `FT-04`'s 5.0005 rounds half up to
5.001. `FT-04`'s `OFFLINE` row does not count.

## Issues CSV

With `--issues PATH` the skipped samples are written to `PATH`, header only when
nothing was skipped:

| Column | Meaning |
| --- | --- |
| `sample_id` | Identifier of the skipped sample (empty when it had none). |
| `reason` | Why it was skipped; see the table below. |
| `input` | The input file the skipped row came from. |
| `value` | The raw `value` text of that row. |

| Reason | Meaning |
| --- | --- |
| `invalid_value` | The value is not a usable number (for example `broken`, `bad`, empty, or infinite). |
| `missing_device_id` | The row has no instrument identifier, so it cannot be grouped. |
| `missing_sample_id` | The row has no `sample_id`, so it cannot be merged or de-duplicated. |

Only rows with a valid status (`OK` or `VALID`) are reported here; a row with
another status is ignored by the rules rather than being an error. Duplicate
records are not issues either, they are simply counted once (and announced on
stdout). Conflicting records are errors, not issues, and stop the run.

For the three example files:

    sample_id,reason,input,value
    S-007,invalid_value,data/day2.csv,broken
    S-013,invalid_value,data/day3.csv,bad

## Rules

These come from `docs/report_policy.md`, which is the authority for them:

1. Samples with status `OK` or `VALID` are valid. Any other status is skipped.
2. Identical records sharing a `sample_id` are counted once; conflicting contents
   for one `sample_id` is an error.
3. Statistics use exact decimal arithmetic, not binary floats.
4. The mean precision and rounding mode are decided by `docs/report_policy.md`
   (currently 3 decimal places, round half up).
5. Only instruments that have at least one valid numeric sample are reported.
   If no instrument qualifies, the output CSV contains only the header row.
6. Input files are never modified; the report is written only to `--output` and
   the skipped samples only to `--issues`.

Values that are not numbers (for example `broken` or `bad`) and blank values are
treated as having no usable sample, so they do not count toward `count` and do not
affect `min`, `max` or `mean`; they are listed in the issues CSV when requested. A
sample without a `device_id` is skipped as well.