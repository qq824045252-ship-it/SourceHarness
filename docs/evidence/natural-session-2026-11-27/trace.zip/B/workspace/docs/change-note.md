# Change note: first release vs current release

An audit of the first release of the sampling report against the current one.
Two things changed: which statuses count as valid, and how many decimal places the
mean is rounded to. The `WARMUP` row in `data/day1.csv` is the clearest example of
the status change, so it is audited first.

## The WARMUP row in the original day1.csv

The row, exactly as it appears in the first release's `data/day1.csv`:

    S-WARM-017,FT-02,812.037,WARMUP

| Field | Value |
| --- | --- |
| `sample_id` | `S-WARM-017` |
| `device_id` | `FT-02` |
| original `value` | `812.037` |
| `status` | `WARMUP` |

It was excluded because of its **status**, not its value:

1. The first release's policy allowed one valid status only: *"Valid statuses: OK."*
   `WARMUP` is not on that list, so the row was never a candidate sample.
2. The first release's code applied that rule before looking at the number. The
   status filter ran first (`is_valid_status` compared the trimmed status with
   `"OK"`), and only rows that survived it reached the decimal parse. A non-valid
   status was dropped whether or not the value was usable.
3. `812.037` is in fact a perfectly well-formed decimal, so nothing about the value
   caused the exclusion. It is a pure status decision.
4. Skipping it was silent, and correctly so: a status that does not count is not a
   data error. The first release had no `--issues` file at all, and the current
   release still does not list this row as an issue, because the issues file only
   records skipped *valid-status* rows (bad or missing value, missing instrument,
   missing sample_id).

Effect on the reported numbers: `FT-02` on day1 is computed from `-2.005` alone in
the first release, giving `FT-02,1,-2.005,-2.005,-2.01`. Had the row counted, its
`812.037` would have dominated that instrument's mean. The current *code* still
excludes `WARMUP` (it is not in `VALID_STATUSES`), so the widened status set added
`VALID`, not `WARMUP`.

## Where the WARMUP row is now

The row is no longer in the delivered data. The first-release `data/day1.csv` had
7 lines (175 bytes) and carried `S-WARM-017`; the current `data/day1.csv` has 6
lines (143 bytes) and no `WARMUP` row at all:

    sample_id,device_id,value,status
    S-001,FT-01,1.00,OK
    S-002,FT-01,1.01,OK
    S-003,FT-02,-2.005,OK
    S-004,FT-02,7.25,VALID
    S-005,FT-03,93.3,OFFLINE

So the row audited above exists only in the first-release snapshot. Removing it
changes no reported number, because it never contributed: it was excluded by
status in both releases. `FT-02` on day1 is still `FT-02,2,-2.005,7.25,2.623` in
the current release — the `VALID` 7.25 row counts now, the `WARMUP` row never did.

One documentation drift is worth recording: `docs/usage.md` still describes `FT-02`
as having *"plus a `WARMUP` row"* in day1, although that row is gone from the
data. The numbers that doc quotes are still correct; the wording describes the
first-release file rather than the current one. The existing docs were left
unchanged when this note was added.

## Valid statuses

| | First release | Current release |
| --- | --- | --- |
| Policy wording | *"Valid statuses: OK."* | *"Valid statuses: OK and VALID."* |
| Code | `VALID_STATUS = "OK"`; `is_valid_status` returned `status.strip() == "OK"` | `VALID_STATUSES = ("OK", "VALID")`; `is_valid_status` returns `status.strip() in VALID_STATUSES` |
| Statuses that count | `OK` | `OK`, `VALID` |
| Still excluded | `VALID`, `WARMUP`, `OFFLINE`, anything else | `WARMUP`, `OFFLINE`, anything else |

`VALID` rows that the current release counts, and the first release did not:
`S-004` (`FT-02`, 7.25), `S-008` (`FT-02`, 1.999), `S-011` (`FT-01`, 4.125) and
`S-014` (`FT-04`, 5.0005). `S-WARM-017` (`WARMUP`) and `S-015` (`OFFLINE`) remain
excluded in both releases.

## Mean precision

| | First release | Current release |
| --- | --- | --- |
| Policy wording | *"Round the mean to 2 decimal places using round half up."* | *"Round the mean to 3 decimal places using round half up."* |
| Code | `MEAN_QUANTUM = Decimal("0.01")` | `MEAN_QUANTUM = Decimal("0.001")` |
| Decimal places | 2 | 3 |
| Rounding mode | `ROUND_HALF_UP` | `ROUND_HALF_UP` (unchanged) |
| Arithmetic | `Decimal`, never floats | `Decimal`, never floats (unchanged) |

Only the quantum changed; the rounding mode and the decimal arithmetic were already
correct in the first release. `min` and `max` were and still are reported at the
precision written in the input, so they are unaffected by this change.

Worked example, `FT-01` over day1 only — the same inputs, two precisions:

| | Values | Exact mean | First release (2 dp) | Current release (3 dp) |
| --- | --- | --- | --- | --- |
| `FT-01` | 1.00, 1.01 | 1.005 | `1.01` | `1.005` |

## Other differences between the releases

| | First release | Current release |
| --- | --- | --- |
| Inputs | one `--input` | `--input` repeatable, merged |
| Duplicates | n/a | identical `sample_id` counted once |
| Conflicts | n/a | differing contents for one `sample_id` is a hard error, nothing written |
| Skipped samples | silently dropped | reported via optional `--issues` CSV |
| Example data | `data/day1.csv`, `data/day2.csv` | plus `data/day3.csv` |

## Evidence

Historical snapshots and events that back the statements above:

| Item | Snapshot ref | Revision | Recorded at |
| --- | --- | --- | --- |
| Original `data/day1.csv` (contains `S-WARM-017,FT-02,812.037,WARMUP`) | `r31`, output hash `d0a57fbc…` | `849b409ad91c2dc040827a6e80dd3b50c43ae93a595c1c1c05b15cfcd7270ec6` | read event 32 (run 1), re-read event 203 (run 185), event 262 |
| First release policy (`OK` only, 2 dp) | `r14`, output hash `4ee8106b…` | `9f56b1086af4edbb40c95e52d8869c47d584ea362136e98738766709d0aedf7e` | read event 15 (run 1), re-read event 98 (run 1), event 264 |
| Current `data/day1.csv` (no `WARMUP` row, 6 lines) | `r317` | `31558f9f51904d4e2d426d8a81ab9d58f4d569b0d0e73ad294762c826d8d7e93` | read in this audit |
| Current policy (`OK` and `VALID`, 3 dp) | — | `21f1a79fc405033ec4c5edc1cc6cb858ad512f48120c4e9dc33b29460a906fee` | read in this audit |
| First release acceptance run (README examples run: 1) | receipt `r90` | program `5353e232…` | operation 1.7.1 |
| Current release acceptance run (README examples run: 2) | receipt `r242` | program `5353e232…` | operation 185.8.1 |
| Audit check of this note's workspace (passed, no README examples executed) | receipts `r303`, `r345` | program `5353e232…` | operations 258.4.1, 258.10.1 |

After the first release `data/day1.csv` was edited: the `WARMUP` row was removed
and the file went from 7 lines (revision `849b409a…`) to 6 lines (revision
`31558f9f…`). The `WARMUP` row described above therefore comes from the
first-release snapshot, not from the delivered data.

Per the maintainer note in the README, the precision decision lives in
`docs/report_policy.md`; this note records the change, it does not define it.