# Instrument sampling reports

Turn one or more raw instrument sample CSVs into a per-instrument summary of
the valid sample count, minimum, maximum, and mean. The business rules are in
`docs/report_policy.md`; the input/output details are in `docs/usage.md`.

## Runnable example

Run this from the project root:

```
python sample_report.py --input data/day1.csv --output summary.csv
```

It prints:

```
6 unique record(s) read from data/day1.csv; 2 instrument(s) written to summary.csv
```

The generated `summary.csv` uses the columns `device_id,count,min,max,mean`:

```
device_id,count,min,max,mean
FT-01,2,1.00,1.01,1.005
FT-02,2,-2.005,7.25,2.623
```

Samples whose `status` is one of the valid statuses in the report policy
(`OK` and `VALID`) and whose `value` is numeric are counted; statistics use
decimal arithmetic and the mean is rounded half up to the number of decimal
places the policy sets (currently 3). Instruments without any valid sample are
left out.

## Combining several files

Repeat `--input` to process several raw files as one data set; a single
`--input` keeps working as before. Records sharing a `sample_id` are counted
once when their contents are identical, and conflicting contents stop the run
with an error. Add `--issues` to collect the samples that were skipped because
their value was not a number:

```
python sample_report.py --input data/day1.csv --input data/day2.csv --input data/day3.csv --output summary.csv --issues issues.csv
```

It prints:

```
16 unique record(s) read from data/day1.csv, data/day2.csv, data/day3.csv; 4 instrument(s) written to summary.csv; 2 duplicate row(s) counted once; 2 issue(s) written to issues.csv
```

`summary.csv`:

```
device_id,count,min,max,mean
FT-01,4,1.00,4.125,2.335
FT-02,4,-4.50,7.25,0.686
FT-03,1,0.75,0.75,0.750
FT-04,1,5.0005,5.0005,5.001
```

`issues.csv`:

```
sample_id,reason
S-007,value 'broken' is not numeric
S-013,value 'bad' is not numeric
```

`S-002` (day1 and day2) and `S-008` (day2 and day3) appear twice with identical
contents, so each contributes one sample. `S-007` and `S-013` carry a valid
status but an unusable value, so they are reported as issues instead of
aborting the run.

The raw inputs in `data/` and `docs/report_policy.md` are read-only for this
tool; write results to new paths such as `summary.csv` and `issues.csv`.

> Maintainer note: Keep degree-of-precision decisions in the report policy.