# Usage

`sample_report.py` turns one or more raw instrument sample CSVs into a single
per-instrument summary CSV. The business rules live in
`docs/report_policy.md`; this page explains how to feed the tool and what it
emits.

## Running the report

```
python sample_report.py --input <raw-samples.csv> [--input <more-samples.csv> ...] --output <summary.csv> [--issues <issues.csv>]
```

| Option | Meaning |
| --- | --- |
| `--input` | Path of a raw sample CSV to read. Required. Repeat the option to combine several files into one report; a single `--input` keeps working as before. Every input is opened read-only and never modified. |
| `--output` | Path of the summary CSV to write. Required. An existing file is overwritten; parent directories are not created. |
| `--issues` | Optional path of a CSV listing the samples that were skipped because their value was not a usable number. An existing file is overwritten; with no skipped samples only the header is written. |

On success the script prints one line with how many unique records were read,
how many instruments were written, how many duplicate rows were collapsed, and
how many issues were listed; it then exits with status `0`.

```
python sample_report.py --input data/day1.csv --output summary.csv
6 unique record(s) read from data/day1.csv; 2 instrument(s) written to summary.csv
```

## Rules come from the report policy

The valid statuses and the number of decimal places used for the mean are read
from `docs/report_policy.md` by `reporting/policy.py`, so a policy change does
not need a code change. The current policy accepts `OK` and `VALID`, uses
decimal arithmetic, and rounds the mean half up to 3 decimal places. If the
policy document cannot be read, the same values are used as built-in defaults.

## Combining inputs and duplicate records

All `--input` files are read into one data set, in the order given on the
command line. Records are identified by their `sample_id`:

- The **first** occurrence of a `sample_id` is kept.
- A later row with the **same** `sample_id` and **identical contents** (same
  `device_id`, `value`, and `status`, after stripping surrounding whitespace)
  is a duplicate: it is counted once and silently dropped. This applies both
  within one file and across files, so feeding the same file twice, or
  overlapping daily extracts, cannot double-count a sample.
- A later row with the same `sample_id` but **different contents** is a
  conflict. The run stops with a clear error naming the `sample_id`, the two
  files, and the disagreeing columns. Nothing is written, so a partial or
  ambiguous report is never produced. Exit status is `2`.

```
python sample_report.py --input data/day1.csv --input bad-day2.csv --output summary.csv
error: sample_id 'S-002' has conflicting contents: data/day1.csv and bad-day2.csv disagree on value
error: fix the conflicting rows or report from a single file; no output was written
```

Rows with an empty `sample_id` have no identity to compare, so they are never
deduplicated and never trigger a conflict; the normal status/value rules decide
their fate.

## Issues CSV

`--issues` writes a CSV with the columns `sample_id,reason`, in input order,
one row per sample that carried a valid status but whose `value` could not be
read as a finite number:

```
sample_id,reason
S-007,value 'broken' is not numeric
```

Such a value is still skipped instead of aborting the run; the issues file only
makes that skip visible. Rows whose `status` is not valid are not data
problems — they are simply not valid samples — so they are not listed.

## Input format

The input is a CSV file with a header row. These columns are used:

| Column | Meaning |
| --- | --- |
| `sample_id` | Sample identifier used to detect duplicates and conflicts across files. |
| `device_id` | Instrument identifier. Rows with an empty `device_id` are ignored. |
| `value` | The sampled reading, parsed as a decimal number. |
| `status` | Sample status; valid statuses are set by the report policy (`OK` and `VALID`). |

Extra columns are tolerated but ignored, and they do not take part in the
duplicate comparison. Column order does not matter, but the header names must
match exactly. Leading and trailing whitespace around these fields is stripped
before use.

A row is counted as a **valid sample** only when all conditions hold:

1. `sample_id` is unique, or repeats an already-seen record with identical
   contents (otherwise the run fails).
2. `status` is one of the policy's valid statuses, matched case-sensitively
   (`OK` and `VALID` today; `WARMUP`, `OFFLINE`, etc. are skipped).
3. `value` parses as a finite decimal number. A non-numeric value such as
   `broken` is skipped even with a valid status; it is listed in `--issues`
   when requested and never aborts the run.

## Output format

The summary CSV has a header row and the columns
`device_id,count,min,max,mean`, one row per reported instrument:

| Column | Meaning |
| --- | --- |
| `device_id` | Instrument identifier. |
| `count` | Number of valid, deduplicated samples for that instrument. |
| `min` | Smallest valid sample value. |
| `max` | Largest valid sample value. |
| `mean` | Arithmetic mean of the valid samples, rounded half up to the number of decimal places set by the policy (3 today). |

Rules applied to the output:

- All statistics are computed with exact decimal arithmetic, so binary
  floating-point error does not creep into `min`, `max`, or `mean`.
- The mean is rounded half up at the policy's precision, so `1.005` becomes
  `1.005` and `2.6225` becomes `2.623` at 3 decimal places. It is always
  printed with exactly that many decimal places (`0.75` becomes `0.750`).
- `min` and `max` are printed as the decimal values read from the input, with
  no rounding (`5.0005` stays `5.0005`).
- Only instruments that have at least one valid numeric sample appear. An
  instrument whose samples are all invalid, or all non-numeric, is omitted
  entirely rather than reported with a count of `0`.
- Rows are sorted by `device_id` so the report is stable regardless of input
  ordering.
- If no instrument has a valid sample, the output file contains only the header
  line.

## Worked examples

### `data/day1.csv`

```
sample_id,device_id,value,status
S-001,FT-01,1.00,OK
S-002,FT-01,1.01,OK
S-003,FT-02,-2.005,OK
S-WARM-017,FT-02,812.037,WARMUP
S-004,FT-02,7.25,VALID
S-005,FT-03,93.3,OFFLINE
```

```
device_id,count,min,max,mean
FT-01,2,1.00,1.01,1.005
FT-02,2,-2.005,7.25,2.623
```

`FT-03` is absent because its only sample is `OFFLINE`. `FT-02` now counts the
`VALID` reading as well, and `(-2.005 + 7.25) / 2 = 2.6225` rounds half up to
`2.623`.

### `data/day2.csv` alone

```
device_id,count,min,max,mean
FT-01,2,1.01,3.205,2.108
FT-02,1,1.999,1.999,1.999
FT-03,1,0.75,0.75,0.750
```

`FT-01` skips the `OFFLINE` reading and `(1.01 + 3.205) / 2 = 2.1075` rounds
half up to `2.108`. `FT-02` keeps only its `VALID` sample; the `OK` row with
value `broken` is skipped and appears in `--issues`.

### `data/day3.csv` alone

```
device_id,count,min,max,mean
FT-01,1,4.125,4.125,4.125
FT-02,2,-4.50,1.999,-1.251
FT-04,1,5.0005,5.0005,5.001
```

`FT-02` averages `1.999` and `-4.50`: `-1.2505` rounds half up (away from zero)
to `-1.251`. `FT-04` reports its raw `5.0005` while its single-sample mean is
rounded to `5.001`. `S-013` (`bad`) is skipped and listed as an issue, and
`S-015` is `OFFLINE`, so it does not appear.

### All three days together

```
python sample_report.py --input data/day1.csv --input data/day2.csv --input data/day3.csv --output summary.csv --issues issues.csv
16 unique record(s) read from data/day1.csv, data/day2.csv, data/day3.csv; 4 instrument(s) written to summary.csv; 2 duplicate row(s) counted once; 2 issue(s) written to issues.csv
```

`summary.csv`:

```
device_id,count,min,max,mean
FT-01,4,1.00,4.125,2.335
FT-02,4,-4.50,7.25,0.686
FT-03,1,0.75,0.75,0.750
FT-04,1,5.0005,5.0005,5.001
```

`issues.csv`:

```
sample_id,reason
S-007,value 'broken' is not numeric
S-013,value 'bad' is not numeric
```

Of the eighteen raw rows, two are exact repeats (`S-002` in day1 and day2,
`S-008` in day2 and day3), so sixteen unique records remain. `S-007` and
`S-013` have valid statuses but unusable values, so they are skipped and
listed. `FT-01` then averages `1.00`, `1.01`, `3.205`, and `4.125`
(`9.340 / 4 = 2.335`), and `FT-02` averages `-2.005`, `7.25`, `1.999`, and
`-4.50` (`2.744 / 4 = 0.686`).

## Exit status

| Status | Meaning |
| --- | --- |
| `0` | Report written (an empty report is still a success). |
| `1` | An input could not be read, or the report/issues file could not be written. |
| `2` | Conflicting contents for one `sample_id`; nothing was written. |

## Protected files

`data/day1.csv`, `data/day2.csv`, `data/day3.csv`, and
`docs/report_policy.md` are inputs and policy, not artifacts. Do not rewrite
them when running the report; point `--output` and `--issues` at new paths
instead.