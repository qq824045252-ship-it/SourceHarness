# Change note: first release vs. current release

This note audits the first release against the version now in the workspace.
It is read-only history: it describes what the code and policy were, and does
not restate or replace `docs/report_policy.md` (which stays the single source
of truth for the rules).

## Evidence used

| Fact | Snapshot | Revision | Event |
| --- | --- | --- | --- |
| First-release policy (`docs/report_policy.md`) | result `r14` | `9f56b108…` | event 15 (run 1), re-read at event 323 (run 297) |
| First-release `data/day1.csv` | result `r33` | `849b409a…` | event 34 (run 1) |
| First-release `reporting/summary.py` | result `r42` | `23f1561b…` | event 246/251 (run 210) show the later edit of the same path |
| First-release `docs/usage.md` | result `r64` | `811183bf…` | — |
| Current policy | result `r214` | `21f1a79f…` | event 215 (run 210) |
| Current `data/day1.csv` | result `r339` | `31558f9f…` | — |
| Acceptance of the first release | result `r101` | workspace `298fd4cb…` | passed |
| Acceptance of the current release | result `r272` | workspace `e9d912ff…` | passed, run 210 |

## The WARMUP row in the original `day1.csv`

The first-release `data/day1.csv` (result `r33`, revision `849b409a…`, 175
bytes) was:

```
sample_id,device_id,value,status
S-001,FT-01,1.00,OK
S-002,FT-01,1.01,OK
S-003,FT-02,-2.005,OK
S-WARM-017,FT-02,812.037,WARMUP
S-004,FT-02,7.25,VALID
S-005,FT-03,93.3,OFFLINE
```

So the WARMUP row was:

- `sample_id` = `S-WARM-017`
- original `value` = `812.037`
- `device_id` = `FT-02`, `status` = `WARMUP`

**Why it was excluded.** The first-release policy said only:

```
- Valid statuses: OK.
```

(result `r14`, revision `9f56b108…`, event 15). The first release implemented
that literally in `reporting/summary.py` (result `r42`, revision `23f1561b…`):

```python
VALID_STATUS = "OK"
MEAN_QUANTUM = Decimal("0.01")

def is_valid_sample(row):
    return (row.get("status") or "").strip() == VALID_STATUS
```

The status test ran before any numeric parsing, so `812.037` was never read as
a number: the row was dropped purely because `WARMUP` is not `OK`. It was a
plain invalid sample, not a data error, so it was never listed as an issue and
never aborted the run. `S-004` (`7.25`, `VALID`) and `S-005` (`93.3`,
`OFFLINE`) were dropped by the same filter.

The visible consequence is in the first-release `docs/usage.md` (result `r64`,
revision `811183bf…`), where `FT-02` reports one sample:

```
device_id,count,min,max,mean
FT-01,2,1.00,1.01,1.01
FT-02,1,-2.005,-2.005,-2.01
```

Under the current policy the same row would still be excluded: `WARMUP` is not
one of the accepted statuses, so accepting `VALID` does not change its fate.

## Valid statuses: first vs. current

| | First release | Current release |
| --- | --- | --- |
| Policy text | `- Valid statuses: OK.` (`r14`, `9f56b108…`, event 15) | `- Valid statuses: OK and VALID.` (`r214`, `21f1a79f…`, event 215) |
| Implementation | `VALID_STATUS = "OK"` (`r42`, `23f1561b…`) | statuses parsed from the policy by `reporting/policy.py`, then `Policy.accepts()` |
| `OK` rows | counted | counted |
| `VALID` rows | skipped | counted |
| `WARMUP` / `OFFLINE` rows | skipped | skipped |

Effect of the change in the bundled data:

- `day1.csv` `S-004` (`7.25`, `VALID`) now counts, so `FT-02` has 2 samples
  instead of 1.
- `day2.csv` `S-008` (`1.999`, `VALID`) now counts and gives `FT-02` a sample.
- `day3.csv` `S-011`, `S-014` (`VALID`) now count; `S-013` (`bad`, `VALID`) now
  reaches the numeric check and is reported through `--issues` instead of
  being ignored as a non-`OK` row.

## Mean precision: first vs. current

| | First release | Current release |
| --- | --- | --- |
| Policy text | `- Round the mean to 2 decimal places using round half up.` (`r14`, `9f56b108…`) | `- Round the mean to 3 decimal places using round half up.` (`r214`, `21f1a79f…`) |
| Implementation | `MEAN_QUANTUM = Decimal("0.01")` (`r42`, `23f1561b…`) | `Policy.mean_quantum` = `Decimal(1).scaleb(-3)` = `0.001`, read from the policy |
| Rounding mode | `ROUND_HALF_UP` | `ROUND_HALF_UP` |
| Arithmetic | `Decimal` | `Decimal` |

Worked differences:

| Value | First release (2 dp) | Current release (3 dp) |
| --- | --- | --- |
| `1.005` | `1.01` | `1.005` |
| `2.6225` | `2.62` | `2.623` |
| `-1.2505` | `-1.25` | `-1.251` |
| `0.75` | `0.75` | `0.750` |

`min` and `max` are unrounded in both releases.

## Rules that did not change

- Statistics use decimal arithmetic (no binary floats).
- Only samples with a valid status *and* a numeric value are counted.
- Instruments without valid samples are omitted; with no valid samples at all,
  only the CSV header is written.
- Input files are never modified; their contents are opaque to the report.
- Smallest/largest values are reported unrounded, in input order of decimals.

## Delivered-state findings

1. **The current `data/day1.csv` no longer contains the WARMUP row.** It is now
   143 bytes with 6 lines (result `r339`, revision `31558f9f…`, formerly 175
   bytes / 7 lines at revision `849b409a…`). `S-WARM-017` was removed after the
   first release. Every per-instrument statistic is unchanged, because that row
   never contributed a sample under either policy — but the *row counts* the
   tool prints do change: `day1.csv` alone is now 5 unique records instead of 6,
   and the three-day run is 15 unique records instead of 16 (17 raw rows, 2
   exact duplicates).
2. **The current `README.md` and `docs/usage.md` quote the pre-change data.**
   Both still show `6 unique record(s) read from data/day1.csv` (README line 18,
   `docs/usage.md` line 26) and `16 unique record(s)` for the three-day run
   (README line 50, `docs/usage.md` line 189); the matching file on disk now
   yields 5 and 15. `docs/usage.md` also still lists
   `S-WARM-017,FT-02,812.037,WARMUP` in its `day1.csv` sample block. All
   `summary.csv` / `issues.csv` figures in both documents remain correct, so the
   drift is limited to row counts and that one quoted input line. Both files are
   left untouched here, since this note is an audit record and the existing docs
   were to stay intact; refreshing those four counts and dropping the quoted
   WARMUP line is the only follow-up needed.
3. Deduplication, conflict detection, and issue reporting introduced after the
   first release are unaffected by the status/precision changes: `VALID` rows
   are deduplicated and conflict-checked on the same `sample_id` rules, and an
   unusable value on a `VALID` row is reported instead of being hidden.