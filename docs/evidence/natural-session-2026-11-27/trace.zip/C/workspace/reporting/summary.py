"""Aggregate instrument samples into per-device statistics.

The rules come from docs/report_policy.md and are loaded by
:mod:`reporting.policy`: the accepted statuses decide which samples count,
arithmetic is decimal, and the mean is rounded half up to the number of
decimal places the policy sets. Instruments without valid numeric samples
are omitted entirely.
"""

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from reporting import policy

POLICY = policy.load()


def parse_value(raw):
    """Return ``raw`` as a finite Decimal, or None when it is not numeric."""
    if raw is None:
        return None
    text = raw.strip()
    if not text:
        return None
    try:
        value = Decimal(text)
    except InvalidOperation:
        return None
    if not value.is_finite():
        return None
    return value


def is_valid_sample(row):
    """True when the row's status is a valid status from the policy."""
    return POLICY.accepts(row.get("status"))


def _issue(row, reason):
    """Issue record naming the skipped sample and why it was skipped."""
    return {
        "sample_id": (row.get("sample_id") or "").strip(),
        "reason": reason,
    }


def _value_problem(raw):
    """Reason text when ``raw`` is not a usable number, else None."""
    text = "" if raw is None else raw.strip()
    if not text:
        return "value is empty"
    try:
        value = Decimal(text)
    except InvalidOperation:
        return f"value {text!r} is not numeric"
    if not value.is_finite():
        return f"value {text!r} is not finite"
    return None


def collect(rows, issues=None):
    """Map device_id -> list of valid numeric Decimal samples, in input order.

    When ``issues`` is a list, one entry is appended for every row with a
    valid status whose value cannot be read as a number. Rows with any other
    status are simply not valid samples and are not reported as data problems.
    """
    samples = {}
    for row in rows:
        if not is_valid_sample(row):
            continue
        problem = _value_problem(row.get("value"))
        if problem is not None:
            if issues is not None:
                issues.append(_issue(row, problem))
            continue
        device_id = (row.get("device_id") or "").strip()
        if not device_id:
            continue
        samples.setdefault(device_id, []).append(parse_value(row.get("value")))
    return samples


def summarize(rows, issues=None, active_policy=None):
    """Return per-instrument stats, sorted by device_id, values pre-formatted."""
    rules = POLICY if active_policy is None else active_policy
    samples = collect(rows, issues=issues)
    summaries = []
    for device_id in sorted(samples):
        values = samples[device_id]
        count = len(values)
        total = sum(values, Decimal(0))
        mean = (total / Decimal(count)).quantize(
            rules.mean_quantum, rounding=ROUND_HALF_UP
        )
        summaries.append(
            {
                "device_id": device_id,
                "count": count,
                "min": str(min(values)),
                "max": str(max(values)),
                "mean": str(mean),
            }
        )
    return summaries