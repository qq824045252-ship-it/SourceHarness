"""Merge sample rows coming from one or more input files.

Rows are identified by ``sample_id``. The same ``sample_id`` may legitimately
appear in several files (for example a rollover sample captured twice); such a
repeat is counted once when its contents are identical. When two rows share a
``sample_id`` but disagree on ``device_id``, ``value``, or ``status``, the run
fails loudly instead of silently picking a winner.
"""

RECORD_COLUMNS = ("sample_id", "device_id", "value", "status")


class ConflictingSample(ValueError):
    """Two rows share a sample_id but do not carry the same contents."""

    def __init__(self, sample_id, first_origin, second_origin, differing):
        self.sample_id = sample_id
        self.first_origin = first_origin
        self.second_origin = second_origin
        self.differing = tuple(differing)
        super().__init__(
            f"sample_id {sample_id!r} has conflicting contents: "
            f"{first_origin} and {second_origin} disagree on "
            f"{', '.join(self.differing)}"
        )


def _normalized(row):
    return {
        key: ("" if value is None else str(value).strip())
        for key, value in row.items()
        if key is not None
    }


def row_signature(row):
    """Fingerprint of the columns that define a record's contents.

    Columns outside :data:`RECORD_COLUMNS` are ignored by the report, so they
    cannot create a duplicate or a conflict either.
    """
    fields = _normalized(row)
    return tuple((column, fields.get(column, "")) for column in RECORD_COLUMNS)


def _differing_fields(first, second):
    left, right = _normalized(first), _normalized(second)
    changed = [
        column
        for column in RECORD_COLUMNS
        if left.get(column, "") != right.get(column, "")
    ]
    return changed or ["contents"]


def merge(labeled_rows):
    """Deduplicate rows by ``sample_id``.

    ``labeled_rows`` is an iterable of ``(origin, rows)`` pairs. Returns
    ``(merged_rows, duplicate_count)`` in first-seen order. Raises
    :class:`ConflictingSample` when a repeated id has different contents.
    """
    merged = []
    seen = {}
    duplicates = 0
    for origin, rows in labeled_rows:
        for row in rows:
            sample_id = (row.get("sample_id") or "").strip()
            if not sample_id:
                # Nothing to deduplicate against; keep the row and let the
                # status/value rules decide its fate.
                merged.append(row)
                continue
            signature = row_signature(row)
            if sample_id not in seen:
                seen[sample_id] = (signature, origin, row)
                merged.append(row)
                continue
            previous_signature, previous_origin, previous_row = seen[sample_id]
            if previous_signature == signature:
                duplicates += 1
                continue
            raise ConflictingSample(
                sample_id,
                previous_origin,
                origin,
                _differing_fields(previous_row, row),
            )
    return merged, duplicates