import csv

COLUMNS = ("device_id", "count", "min", "max", "mean")
ISSUE_COLUMNS = ("sample_id", "reason")


def read_rows(path):
    with open(path, newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def _write(path, fieldnames, rows):
    with open(path, "w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(fieldnames))
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def write_summary(path, summaries, columns=COLUMNS):
    """Write summary rows to ``path``; with no rows only the header is written."""
    _write(path, columns, summaries)


def write_issues(path, issues, columns=ISSUE_COLUMNS):
    """Write skipped-sample rows to ``path``; with no rows only the header."""
    _write(path, columns, issues)