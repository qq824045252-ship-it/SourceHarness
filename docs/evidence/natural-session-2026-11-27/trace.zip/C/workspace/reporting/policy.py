"""Read the reporting rules from ``docs/report_policy.md``.

The maintainer note in README.md asks that degree-of-precision decisions stay
in the report policy, so the accepted statuses and the number of decimal
places used for the mean are read from that document instead of being
duplicated in the reporting code. If the document cannot be read the built-in
defaults below are used; they match the current policy.
"""

import re
from decimal import Decimal
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_POLICY_PATH = PROJECT_ROOT / "docs" / "report_policy.md"

DEFAULT_STATUSES = ("OK", "VALID")
DEFAULT_MEAN_PLACES = 3

_STATUS_LINE = re.compile(r"valid statuses?\s*:\s*(.+)", re.IGNORECASE)
_MEAN_PLACES_LINE = re.compile(
    r"mean\s+to\s+(\d+)\s+decimal\s+places?", re.IGNORECASE
)


class Policy:
    """The rules that decide what counts and how the mean is rounded."""

    def __init__(self, statuses, mean_places, source=None):
        self.statuses = tuple(statuses)
        self.mean_places = int(mean_places)
        self.source = source

    @property
    def mean_quantum(self):
        """The Decimal step the mean is rounded to, e.g. 0.001 for 3 places."""
        return Decimal(1).scaleb(-self.mean_places)

    def accepts(self, status):
        """True when ``status`` is one of the policy's valid statuses."""
        return (status or "").strip() in self.statuses

    def __repr__(self):
        return (
            f"Policy(statuses={self.statuses!r}, "
            f"mean_places={self.mean_places!r}, source={self.source!r})"
        )


def _clean_statuses(raw):
    parts = re.split(r",|\band\b", raw)
    return tuple(
        part.strip().strip("`'\"*_ .")
        for part in parts
        if part.strip().strip("`'\"*_ .")
    )


def parse(text, source=None):
    """Extract the statuses and mean precision from policy text."""
    statuses = DEFAULT_STATUSES
    mean_places = DEFAULT_MEAN_PLACES
    for line in text.splitlines():
        match = _STATUS_LINE.search(line)
        if match:
            found = _clean_statuses(match.group(1))
            if found:
                statuses = found
            continue
        match = _MEAN_PLACES_LINE.search(line)
        if match:
            mean_places = int(match.group(1))
    return Policy(statuses, mean_places, source=source)


def load(path=None):
    """Load the policy document, falling back to the built-in defaults."""
    target = DEFAULT_POLICY_PATH if path is None else Path(path)
    try:
        text = target.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return Policy(DEFAULT_STATUSES, DEFAULT_MEAN_PLACES)
    return parse(text, source=str(target))