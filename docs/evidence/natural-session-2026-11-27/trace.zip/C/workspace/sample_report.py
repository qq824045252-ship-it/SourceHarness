"""Build a per-instrument sampling report from one or more raw sample CSVs."""

import argparse
import sys

from reporting.csv_io import read_rows, write_issues, write_summary
from reporting.records import ConflictingSample, merge
from reporting.summary import summarize


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="Summarize instrument samples into a CSV report."
    )
    parser.add_argument(
        "--input",
        required=True,
        action="append",
        metavar="CSV",
        dest="inputs",
        help=(
            "raw sample CSV to read (left unchanged); repeat --input to "
            "combine several files into one report"
        ),
    )
    parser.add_argument(
        "--output", required=True, help="summary CSV to write"
    )
    parser.add_argument(
        "--issues",
        metavar="CSV",
        help="optional CSV listing skipped samples as sample_id,reason",
    )
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)

    labeled_rows = []
    for path in args.inputs:
        try:
            labeled_rows.append((path, read_rows(path)))
        except (OSError, UnicodeDecodeError) as error:
            print(f"error: cannot read {path}: {error}", file=sys.stderr)
            return 1

    try:
        rows, duplicates = merge(labeled_rows)
    except ConflictingSample as error:
        print(f"error: {error}", file=sys.stderr)
        print(
            "error: fix the conflicting rows or report from a single file; "
            "no output was written",
            file=sys.stderr,
        )
        return 2

    issues = []
    summaries = summarize(rows, issues=issues)

    try:
        write_summary(args.output, summaries)
        if args.issues:
            write_issues(args.issues, issues)
    except OSError as error:
        print(f"error: cannot write report: {error}", file=sys.stderr)
        return 1

    parts = [
        f"{len(rows)} unique record(s) read from {', '.join(args.inputs)}",
        f"{len(summaries)} instrument(s) written to {args.output}",
    ]
    if duplicates:
        parts.append(f"{duplicates} duplicate row(s) counted once")
    if args.issues:
        parts.append(f"{len(issues)} issue(s) written to {args.issues}")
    print("; ".join(parts))
    return 0


if __name__ == "__main__":
    sys.exit(main())