# Operations policy POL-096
Only the primary section moves to the policy settings.
Its timeout is 75.
Its retry count is 4.
Use the policy identifier in the evidence note.
