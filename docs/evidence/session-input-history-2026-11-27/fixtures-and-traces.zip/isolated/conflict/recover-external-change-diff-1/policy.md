# Operations policy POL-072
Only the primary section moves to the policy settings.
Its timeout is 60.
Its retry count is 3.
Use the policy identifier in the evidence note.
