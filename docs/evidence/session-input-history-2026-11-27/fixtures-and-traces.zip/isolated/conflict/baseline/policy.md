# Operations policy POL-031
Only the primary section moves to the policy settings.
Its timeout is 30.
Its retry count is 2.
Use the policy identifier in the evidence note.
