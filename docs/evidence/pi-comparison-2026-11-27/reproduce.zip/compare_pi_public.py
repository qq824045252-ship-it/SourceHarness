from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import contextmanager
import getpass
import http.server
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import threading
import time
from urllib import error, request
import uuid

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "SourceHarness"
sys.path.insert(0, str(REPO / "scripts"))
from natural_session_cases import CASES, apply_external_changes, protected_paths, seed
from session_eval_cases import encode, sha, workspace_files
from eval_natural_session import reported_validation

MODEL = "deepseek-v4.1-flash"
EFFORT = "low"
ENDPOINT = "https://opencode.ai/inference/go/openai/v1/responses"
SH = REPO / "target/debug/source_harness"
PI = ROOT / "node_modules/@earendil-works/pi-coding-agent/dist/bundle/cli.js"
NODE = Path(shutil.which("node")).resolve().parent.parent
MAX_ATTEMPTS = 16
PHASE_TIMEOUT = 600
PROMPT_SUFFIX = ("\nRun the configured acceptance check against the final workspace and report its result. "
                 "Use validate with check=acceptance, or run the acceptance command if you have a shell.")
CASES_AND_COUNTS = [("markdown-links", range(1, 4), 2), ("sample-report", range(1, 2), 2)]


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


class NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Models:
    def __init__(self):
        self.phase = 0
        self.rows = []

    def start(self, phase):
        self.phase = phase

    def begin(self, raw, body):
        row = {
            "phase": self.phase, "request": len(self.rows) + 1, "body_bytes": len(raw),
            "body_sha256": sha(raw), "model": body["model"],
            "effort": (body.get("reasoning") or {}).get("effort"),
            "tools": [t.get("name") for t in body.get("tools", [])],
            "input_items": len(body.get("input", [])), "response_model": None, "usage": None,
            "status": None, "output_types": [], "seconds": None,
        }
        self.rows.append(row)
        return row


@contextmanager
def bridge(token, arm, label, models, acceptance_check):
    client_session = "ses_" + uuid.uuid4().hex
    opener = request.build_opener(NoRedirect())

    class ResponseProxy(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_GET(self):
            if self.path != "/benchmark/acceptance" or arm != "pi":
                self.send_error(404)
                return
            result = acceptance_check()
            raw = json.dumps(result, separators=(",", ":")).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_POST(self):
            if self.path != "/v1/responses":
                self.send_error(404)
                return
            raw = self.rfile.read(int(self.headers["Content-Length"]))
            payload = json.loads(raw)
            row = models.begin(raw, payload)
            nr = sum(r["phase"] == row["phase"] and r.get("forwarded") for r in models.rows
                     if r.get("forwarded"))
            if nr >= MAX_ATTEMPTS or row["model"] != MODEL or row["effort"] != EFFORT:
                row["status"], row["forwarded"] = 400, False
                row["failure"] = "request budget" if nr >= MAX_ATTEMPTS else "model or effort mismatch"
                self.send_error(400, row["failure"])
                return
            request_upstream = request.Request(ENDPOINT, data=raw, headers={
                "Authorization": "Bearer " + token, "Content-Type": "application/json",
                "Accept": "text/event-stream", "x-opencode-session": client_session,
                "User-Agent": "Pi/1.6.1" if arm == "pi" else "SourceHarness/0.1.0",
            })
            row["forwarded"] = True
            start = time.monotonic()
            try:
                with opener.open(request_upstream, timeout=105) as stream:
                    row["status"] = stream.status
                    self.send_response(stream.status)
                    self.send_header("Content-Type", stream.headers.get("Content-Type", "text/event-stream"))
                    self.end_headers()
                    for line in stream:
                        if line.startswith(b"data: "):
                            try:
                                event = json.loads(line[6:])
                            except ValueError:
                                event = {}
                            if isinstance(event, dict) and event.get("type") in ("response.completed", "response.incomplete"):
                                result = event.get("response") or {}
                                row["usage"] = result.get("usage")
                                row["response_model"] = result.get("model")
                                row["output_types"] = [item.get("type") for item in result.get("output", [])]
                                row["terminal"] = event["type"]
                                row["seconds"] = round(time.monotonic() - start, 3)
                        self.wfile.write(line)
                        self.wfile.flush()
            except error.HTTPError as exc:
                row["status"] = exc.code
                body = exc.read(65536).replace(token.encode(), b"[credential]")
                row["error"] = body.decode(errors="replace")[:700]
                self.send_response(exc.code)
                self.end_headers()
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except OSError as exc:
                row["error"] = str(exc).replace(token, "[credential]")
                if row["status"] is None:
                    row["status"] = 502
                    self.send_error(502, "Benchmark upstream unavailable")
            finally:
                if row["seconds"] is None:
                    row["seconds"] = round(time.monotonic() - start, 3)

    with http.server.ThreadingHTTPServer(("127.0.0.1", 0), ResponseProxy) as server:
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            yield f"http://127.0.0.1:{server.server_port}/v1"
        finally:
            server.shutdown()
            thread.join()


def sandbox(workspace, config, state, launch, grader_mounted=True):
    mounts = ([
        "--ro-bind", str(ROOT / "public-fixtures"), "/graders",
        "--ro-bind", str(SH), "/bin-src/source_harness",
        "--ro-bind", str(ROOT / "acceptance"), "/bench/acceptance",
        "--ro-bind", str(config), "/config",
    ] if grader_mounted else [
        "--ro-bind", str(ROOT / "pi-acceptance"), "/bench/acceptance",
    ])
    return [
        "bwrap", "--unshare-all", "--share-net", "--die-with-parent", "--new-session", "--clearenv",
        "--ro-bind", "/usr", "/usr", "--symlink", "usr/bin", "/bin", "--symlink", "usr/lib", "/lib",
        "--symlink", "usr/lib64", "/lib64", "--ro-bind", str(NODE), "/node",
        "--ro-bind", str(ROOT / "node_modules"), "/pi/node_modules",
        "--ro-bind", "/opt/codex/codex-path/rg", "/opt/codex/codex-path/rg",
        *mounts, "--bind", str(workspace), "/work",
        "--bind", str(state), "/state", "--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp",
        "--chdir", "/work", "--setenv", "PATH", "/bench:/usr/local/bin:/usr/bin:/bin:/node/bin",
        "--setenv", "HOME", "/state", "--setenv", "PI_CODING_AGENT_DIR", "/state/pi",
        "--setenv", "LANG", "C.UTF-8", "--setenv", "PYTHONNOUSERSITE", "1",
        *launch
    ]

def launch(arm, url, prompt, phase):
    if arm == "sourceharness":
        return ["--setenv", "OPENAI_BASE_URL", url, "--", "/bin-src/source_harness", "agent",
                "--root", "/work", "--session", "work", "--checks", "/config/checks.json",
                "--model", MODEL, "--effort", EFFORT, "--edit-mode", "text", "--receipt-mode", "versioned",
                "--history-mode", "events", "--freshness-instructions", "on", "--stale-projection", "on",
                "--workspace-change-notices", "on", "--prompt", prompt]
    cli = "/pi/node_modules/@earendil-works/pi-coding-agent/dist/bundle/cli.js"
    check_url = url.removesuffix("/v1") + "/benchmark/acceptance"
    return ["--setenv", "BENCH_ACCEPTANCE_URL", check_url, "--", "/node/bin/node", cli, "--mode", "json",
            "--print", "--provider", "paired-go",
            "--model", MODEL, "--thinking", EFFORT, "--no-mcp", "--no-extensions", "--no-skills",
            "--no-prompt-templates", "--no-context-files", "--no-themes", "--session-dir", "/state/sessions",
            *(["--continue"] if phase > 1 else []), prompt]


def extract_json(text):
    for line in text.splitlines():
        try:
            value = json.loads(line)
        except ValueError:
            continue
        if isinstance(value, dict):
            yield value


def call_readout_source(events, workspace_revision, oracle_revision):
    checks = []
    tools = []
    final = None
    for event in events:
        data = event["data"]
        if event["kind"] == "validation_receipt":
            matched = bool(data.get("passed") and data["workspace_revision"] == workspace_revision
                           and data.get("input_revisions_stable")
                           and data.get("input_revisions", {}).get("/config/oracle.json") == oracle_revision)
            checks.append({"index": event["seq"], "passed": data["passed"], "verified_final": matched})
        if event["kind"] == "tool_attempt":
            tools.append({"index": event["seq"], "name": data["name"]})
        if event["kind"] == "model_response" and data.get("final_text"):
            final = data["final_text"]
    return checks, tools, final


def call_readout_pi(events, workspace_revision, oracle_revision, brokered):
    checks = []
    tools = []
    final = None
    for i, event in enumerate(events):
        kind = event["type"]
        if kind == "tool_execution_start":
            tools.append({"index": i, "name": event["toolName"]})
        if kind == "tool_execution_end" and event["toolName"] == "bash":
            result = event.get("result") or {}
            for part in result.get("content", []):
                for record in extract_json(part.get("text", "")):
                    if "workspace_revision" not in record or "oracle_revision" not in record:
                        continue
                    matched = bool(record.get("passed") and record.get("stable_workspace")
                                   and record["workspace_revision"] == workspace_revision
                                   and record["oracle_revision"] == oracle_revision and record in brokered)
                    checks.append({"index": i, "passed": record["passed"], "verified_final": matched})
        if kind == "agent_end":
            messages = [m for m in event.get("messages", []) if m.get("role") == "assistant"]
            if messages and messages[-1].get("stopReason") == "stop":
                final = "\n".join(p["text"] for p in messages[-1]["content"] if p["type"] == "text")
    return checks, tools, final


def session_events(ws):
    path = ws / ".sourceharness/sessions/work/events.jsonl"
    return list(extract_json(path.read_text())) if path.exists() else []


def cost(rows):
    upstream = [r for r in rows if r["forwarded"]]
    known = [r["usage"] for r in upstream if (r["usage"] or {}).get("total_tokens") is not None]
    cache = [(r.get("input_tokens_details") or {}).get("cached_tokens") for r in known]
    return {
        "model_requests": len(upstream), "requests_without_usage": len(upstream) - len(known),
        "request_statuses": dict(Counter(r["status"] for r in upstream)),
        "input_tokens": sum(u.get("input_tokens", 0) for u in known),
        "cached_input_tokens": sum(c or 0 for c in cache),
        "requests_without_cache_usage": len(upstream) - sum(c is not None for c in cache),
        "output_tokens": sum(u.get("output_tokens", 0) for u in known),
        "reasoning_tokens": sum((u.get("output_tokens_details") or {}).get("reasoning_tokens", 0) for u in known),
        "total_tokens": sum(u["total_tokens"] for u in known),
        "block_count": len(rows) - len(upstream),
        "response_models": sorted({r["response_model"] for r in upstream if r["response_model"]}),
    }


def run_arm(token, arm, case_name, repeat, phases, run_dir):
    case = CASES[case_name]
    trial = run_dir / arm
    trial.mkdir(parents=True)
    workspace = trial / "workspace"
    config = trial / "config"
    state = trial / "state"
    seed(case, workspace)
    config.mkdir()
    state.mkdir()
    settings = {
        "name": "acceptance",
        "program": "/usr/bin/python3", "args": ["-B", "/bench/acceptance"],
        "description": "Check the delivered behavior, documentation, and protected files for the current task.",
        "inputs": ["/config/oracle.json", "/bench/acceptance", "/graders/check_natural_session.py",
                   "/graders/natural_session_cases.py", "/graders/session_eval_cases.py"],
        "timeout_seconds": 60,
    }
    settings.pop("name")
    save(config / "checks.json", {"acceptance": settings})
    models = Models()
    records = []
    actual_checks = []

    def invoke_checker():
        result = subprocess.run(sandbox(
            workspace, config, state, ["--", "/usr/bin/python3", "-B", "/bench/acceptance"]),
            capture_output=True, encoding="utf-8", errors="replace", timeout=65)
        records = list(extract_json(result.stdout))
        return records[-1] if records else {
            "passed": False, "stable_workspace": False, "failures": {"checker": result.stderr[:500]}
        }

    def broker_acceptance():
        outcome = invoke_checker()
        actual_checks.append(outcome)
        return outcome

    with bridge(token, arm, f"{case_name}/{repeat}/{arm}", models, broker_acceptance) as url:
        if arm == "pi":
            pi = state / "pi"
            pi.mkdir()
            (state / "sessions").mkdir()
            save(pi / "models.json", {"providers": {"paired-go": {
                "baseUrl": url, "apiKey": "local-test-bridge", "api": "openai-responses",
                "models": [{"id": MODEL, "name": MODEL, "reasoning": True,
                            "thinkingLevelMap": {"low": "low"}, "contextWindow": 128000, "maxTokens": 16384}],
                "compat": {"supportsDeveloperRole": False, "supportsMaxOutputTokens": False,
                           "supportsStrictMode": False, "promptCacheKeyMode": "disabled",
                           "supportsLongCacheRetention": False},
            }}})
        for phase, raw_prompt in enumerate(case.prompts[:phases], 1):
            old_events = len(session_events(workspace)) if arm == "sourceharness" else 0
            outside = apply_external_changes(case, workspace, phase)
            fixture = workspace_files(workspace)
            oracle = {"case": case_name, "phase": phase,
                      "protected": {name: sha(fixture[name]) for name in protected_paths(case, phase, fixture)}}
            save(config / "oracle.json", oracle)
            oracle_revision = sha((config / "oracle.json").read_bytes())
            prompt = raw_prompt + PROMPT_SUFFIX
            models.start(phase)
            actual_checks.clear()
            command = sandbox(workspace, config, state, launch(arm, url, prompt, phase),
                              grader_mounted=arm == "sourceharness")
            start = time.monotonic()
            try:
                invocation = subprocess.run(command, capture_output=True, encoding="utf-8", errors="replace",
                                            timeout=PHASE_TIMEOUT)
                exit_code, stdout, stderr = invocation.returncode, invocation.stdout, invocation.stderr
            except subprocess.TimeoutExpired as exc:
                exit_code, stdout, stderr = None, (exc.stdout or b"").decode(errors="replace"), "phase timeout"
            wall = round(time.monotonic() - start, 3)
            (trial / f"phase-{phase}.stdout").write_text(stdout.replace(token, "[credential]"))
            (trial / f"phase-{phase}.stderr").write_text(stderr.replace(token, "[credential]"))
            independent = invoke_checker()
            files = workspace_files(workspace)
            revision = sha(encode({name: sha(raw) for name, raw in files.items()}))
            if arm == "sourceharness":
                checked, tools, final = call_readout_source(session_events(workspace)[old_events:], revision, oracle_revision)
            else:
                checked, tools, final = call_readout_pi(list(extract_json(stdout)), revision, oracle_revision, actual_checks)
            enough = next((check["index"] for check in checked if check["verified_final"]), None)
            rows = [r for r in models.rows if r["phase"] == phase]
            claims = reported_validation(final or "", enough is not None, revision)
            natural = bool(exit_code == 0 and final and not any(r.get("failure") == "request budget" for r in rows))
            accepted = bool(independent["passed"] and independent["stable_workspace"])
            strict = bool(natural and accepted and enough is not None and not claims["mismatched_validation_revisions"])
            extra = [t["name"] for t in tools if enough is not None and t["index"] > enough]
            record = {
                "phase": phase, "prompt_sha256": sha(prompt.encode()), "oracle_sha256": oracle_revision,
                "external_changes": outside, "exit": exit_code, "seconds": wall, "accepted": accepted,
                "natural_end": natural, "strict_pass": strict, "verified_final": enough is not None,
                "no_calls_after_verified_final": strict and not extra,
                "calls_after_verified_final": extra if enough is not None else None,
                "tool_attempts": len(tools), "tools": dict(Counter(t["name"] for t in tools)),
                "checks": checked, "independent": independent, "claims": claims,
                "final_workspace_revision": revision, "cost": cost(rows),
                "errors": [r.get("error") or r["failure"] for r in rows if r.get("error") or r.get("failure")],
            }
            records.append(record)
            save(trial / "summary.json", records)
            save(trial / "requests.json", models.rows)
            print(f"{case_name} {repeat} {arm} phase {phase}: "
                  f"accepted={accepted} verified={enough is not None} natural={natural} "
                  f"requests={record['cost']['model_requests']} errors={record['errors'][:1]}",
                  flush=True)
            if not natural:
                break
    return records


def package_run_directory():
    root = ROOT / "public-matched"
    root.mkdir()
    return root


def execute_plan(token, parent, cases):
    jobs = [(arm, case, repeat, phases, parent / f"{case}-{repeat:02}")
            for case, repeats, phases in cases for repeat in repeats
            for arm in (("sourceharness", "pi") if repeat % 2 else ("pi", "sourceharness"))]
    results = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(run_arm, token, *job): job for job in jobs}
        for future in as_completed(futures):
            arm, case, repeat, phases, directory = futures[future]
            try:
                records = future.result()
            except Exception as exc:
                records = []
                print(type(exc).__name__, str(exc).replace(token, "[credential]")[:400], flush=True)
            results.append({"case": case, "pair": repeat, "arm": arm, "expected_phases": phases, "phases": records})
    return results


def main():
    root = package_run_directory()
    print(f"Results directory: {root}", flush=True)
    token = getpass.getpass("Test API credential (hidden): ")
    if not re.fullmatch(r"oc_sk_[A-Za-z0-9_]+", token):
        raise SystemExit("Missing or malformed test credential")
    if "--pilot" in sys.argv:
        cases = [("markdown-links", range(1, 2), 2)]
    elif "--remaining" in sys.argv:
        cases = [("markdown-links", range(2, 4), 2), ("sample-report", range(1, 2), 2)]
    else:
        cases = CASES_AND_COUNTS
    results = execute_plan(token, root, cases)
    report = {
        "provider": "OpenCode Go Responses", "model": MODEL, "effort": EFFORT,
        "grader_access": "Both models see acceptance results. Pi shell has no grader or oracle mount.",
        "fixture_scope": "Three published fixture and checker scripts at e2818d2 with programmed inputs.",
        "sourceharness_commit": subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True).strip(),
        "sourceharness_exe_sha256": sha(SH.read_bytes()),
        "pi_version": json.loads((PI.parents[2] / "package.json").read_bytes())["version"],
        "phase_timeout_seconds": PHASE_TIMEOUT, "model_request_limit_per_phase": MAX_ATTEMPTS,
        "shared_prompt_suffix": PROMPT_SUFFIX,
        "trials": sorted(results, key=lambda x: (x["case"], x["pair"], x["arm"])),
    }
    save(root / "results.json", report)
    print(f"Finished {len(results)} runs", flush=True)


if __name__ == "__main__":
    main()
