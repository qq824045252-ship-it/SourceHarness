from collections import Counter
from pathlib import Path
from statistics import median
import json
import sys


ROOT = Path(__file__).resolve().parent
ARMS = ("sourceharness", "pi")


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def summarize(arm, trials):
    all_phases = [phase for trial in trials for phase in trial["phases"]]
    cost_keys = ("model_requests", "input_tokens", "output_tokens", "total_tokens",
                 "cached_input_tokens", "requests_without_usage", "requests_without_cache_usage", "block_count")
    total = {key: sum(p["cost"][key] for p in all_phases) for key in cost_keys}
    completed = [t for t in trials if len(t["phases"]) == t["expected_phases"]]
    per_session = [{
        "pair": t["pair"], "phases_accepted": sum(p["strict_pass"] for p in t["phases"]),
        "total_tokens": sum(p["cost"]["total_tokens"] for p in t["phases"]),
        "input_tokens": sum(p["cost"]["input_tokens"] for p in t["phases"]),
        "requests": sum(p["cost"]["model_requests"] for p in t["phases"]),
        "elapsed_seconds": sum(p["seconds"] for p in t["phases"]),
    } for t in trials]
    return {
        "arm": arm, "sessions": len(trials), "sessions_completed": len(completed),
        "all_phases_strict_pass": sum(all(p["strict_pass"] for p in t["phases"]) for t in completed),
        "expected_phases": sum(t["expected_phases"] for t in trials),
        "attempted_phases": len(all_phases),
        "independent_passes": sum(p["accepted"] for p in all_phases),
        "strict_passes": sum(p["strict_pass"] for p in all_phases),
        "natural_completions": sum(p["natural_end"] for p in all_phases),
        "verified_final": sum(p["verified_final"] for p in all_phases),
        "strict_pass_with_no_calls_after_final_check": sum(p["no_calls_after_verified_final"] for p in all_phases),
        "calls_after_verified_final": sum(len(p["calls_after_verified_final"] or []) for p in all_phases),
        "tools": dict(sum((Counter(p["tools"]) for p in all_phases), Counter())),
        "tool_attempts": sum(p["tool_attempts"] for p in all_phases),
        "cost": total,
        "aggregate_cache_rate": (total["cached_input_tokens"] / total["input_tokens"]
                                 if total["input_tokens"] and total["requests_without_cache_usage"] == 0 else None),
        "median_session": {key: median(s[key] for s in per_session) if per_session else None
                           for key in ("total_tokens", "input_tokens", "requests", "elapsed_seconds")},
        "per_session": per_session,
    }


def consolidate():
    exploratory = "--exploratory" in sys.argv
    inputs = (sorted(ROOT.glob("measured*/results.json")) if exploratory
              else [ROOT / "public-matched/results.json"])
    assert len(inputs) == (2 if exploratory else 1), inputs
    prefix = "exploratory" if exploratory else "paired"
    common = None
    runs = {}
    all_requests = []
    for path in inputs:
        obj = load(path)
        setup = {key: val for key, val in obj.items() if key != "trials"}
        if common is None:
            common = setup
        assert common == setup
        for trial in obj["trials"]:
            case, pair, arm = trial["case"], trial["pair"], trial["arm"]
            key = (case, pair, arm)
            assert key not in runs, key
            runs[key] = trial
            request_path = path.parent / f"{case}-{pair:02}" / arm / "requests.json"
            if request_path.exists():
                for entry in load(request_path):
                    assert not entry["forwarded"] or entry["model"] == setup["model"] and entry["effort"] == setup["effort"]
                    all_requests.append({"case": case, "pair": pair, "arm": arm, **entry})
    totals = {}
    for case in sorted({k[0] for k in runs}):
        paired = []
        for pair in sorted({k[1] for k in runs if k[0] == case}):
            left, right = (runs[case, pair, arm] for arm in ARMS)
            matched = all(a["prompt_sha256"] == b["prompt_sha256"] and a["external_changes"] == b["external_changes"]
                          for a, b in zip(left["phases"], right["phases"]))
            assert matched
            paired.append({"pair": pair, "prompts_match": matched,
                           "complete": all(len(t["phases"]) == t["expected_phases"] for t in (left, right))})
        totals[case] = {"paired": paired, "arms": {
            arm: summarize(arm, [v for k, v in runs.items() if k[0] == case and k[2] == arm]) for arm in ARMS
        }}
    result = {"setup": common, "scenarios": totals, "trials": [runs[k] for k in sorted(runs)]}
    for scenario, data in totals.items():
        for arm, total in data["arms"].items():
            entries = [r for r in all_requests if r["case"] == scenario and r["arm"] == arm and r["forwarded"]]
            assert len(entries) == total["cost"]["model_requests"]
            assert sum(r["usage"]["total_tokens"] for r in entries if r.get("usage")) == total["cost"]["total_tokens"]
    save(ROOT / f"{prefix}-results.json", result)
    tagged = sorted(all_requests, key=lambda r: (r["case"], r["pair"], r["arm"], r["request"]))
    (ROOT / f"{prefix}-requests.jsonl").write_text(
        "".join(json.dumps(row, separators=(",", ":")) + "\n" for row in tagged), encoding="utf-8")
    print(json.dumps(result["scenarios"], indent=2))


if __name__ == "__main__":
    consolidate()
