import json, re, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ARCHIVE = "refs/backup/sourceharness/main-5c83d8b:docs/evidence/result-convergence-2026-11-26/bootstrap-inline-vs-synthetic.md"
MASK = (1 << 64) - 1

def fnv1a64(data):
    h = 0xcbf29ce484222325
    for byte in data:
        h = ((h ^ byte) * 0x100000001b3) & MASK
    return f"{h:016x}"

def snapshot(case_id):
    n = case_id // 10
    state = 0x20261126f01d843a ^ ((case_id * 0xdb4f0b9175ae2165) & MASK)
    def next_u64():
        nonlocal state
        state = (state + 0x9e3779b97f4a7c15) & MASK
        value = ((state ^ (state >> 30)) * 0xbf58476d1ce4e5b9) & MASK
        value = ((value ^ (value >> 27)) * 0x94d049bb133111eb) & MASK
        return value ^ (value >> 31)

    for _ in range(3):
        next_u64()
    sections = ["Setup Notes", "Release Review", "Dispatch Register", "Legacy Archive",
                "Calibration Queue", "Inventory Snapshots"]
    for i in range(len(sections)-1, 0, -1):
        j = next_u64() % (i+1)
        sections[i], sections[j] = sections[j], sections[i]
    size = [4096, 16384, 65536][n % 3]
    records = [54, 219, 835][n % 3]
    lines = []
    for section in sections:
        lines.append(f"## {section}")
        next_u64()
        for _ in range(records // 6):
            identity = next_u64() & 0xffffffff
            status = "REVIEW" if next_u64() % 19 == 0 else "CLEARED"
            lines.append(f"card {identity:08x}: {status}")
    used = sum(len(line)+1 for line in lines)
    filler = "miscellaneous shift note; no decision recorded"
    full, rest = divmod(size-used, len(filler)+1)
    lines.extend([filler]*full)
    if rest > 1:
        lines.append("."*(rest-1))
    return "\n".join(lines)+"\n"

archive = subprocess.check_output(["git", "show", ARCHIVE]).decode()
cases = {}
for match in re.finditer(r"^### (\d+) / (inline|synthetic)\n(.*?)(?=^### \d+ / (?:inline|synthetic)\n|\Z)", archive, re.M | re.S):
    case_id, arm, block = match.groups()
    case_id = int(case_id)
    if not (23005 <= case_id <= 23355):
        continue
    question = re.search(r"```text\n(.*?)\n```", block, re.S)[1]
    record = next(json.loads(l) for l in block.splitlines()
                  if l.startswith('{"arm"') and '"case_id":' in l)
    doc = snapshot(case_id)
    assert fnv1a64(doc.encode()) == record["snapshot_fnv1a64"], (case_id, fnv1a64(doc.encode()), record["snapshot_fnv1a64"])
    gold = sum(l.endswith(": REVIEW") for l in doc.splitlines())
    assert [str(gold)] == record["gold"], case_id
    case = cases.setdefault(case_id, dict(id=case_id, prompt=question, document=doc, gold=gold,
                                           hash=record["snapshot_fnv1a64"], historical={}))
    assert case["prompt"] == question and arm not in case["historical"]
    case["historical"][arm] = dict(correct="语义复核正确" in block.splitlines()[1],
                                  status=record["outcome"], extra_calls=record["calls_after_enough"],
                                  tokens=record["tokens"])
assert sorted(cases) == list(range(23005, 23356, 10))
assert all(set(c["historical"]) == {"inline", "synthetic"} for c in cases.values())
ordered = sorted(cases.values(), key=lambda c: (-len(c["document"]), c["id"]))
(ROOT/"cases.json").write_text(json.dumps(ordered, ensure_ascii=True), encoding="utf-8")
for size in [4096,16384,65536]:
    group = [c for c in ordered if len(c["document"])//1024 == size//1024]
    if len(group) != 12:
        group = [c for c in ordered if round(len(c["document"])/1024) == size//1024]
    print(size, len(group), min(len(c["document"]) for c in group), max(len(c["document"]) for c in group))
print("Verified 36 archived document fingerprints, paired prompts, and gold counts")
