use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::Path;
use std::sync::{Mutex, atomic::{AtomicUsize, Ordering}};
use std::time::Instant;

use serde_json::{Value, json};
use source_harness::store::{FoldStore, IngestOutcome};
use source_harness::transport::injection::{
    EnvelopeInjector, InlineUserMessageInjector, NativeFunctionCallInjector,
};
use source_harness::transport::{
    GatewayConfig, KernelToolExecutor, ResponsesClient, RunObserver, ToolCallTrace,
    ToolExecutionOutput, ToolExecutor, TurnMetrics,
};

struct RecordedExecutor<'a> {
    inner: KernelToolExecutor<'a>,
    replies: Mutex<Vec<Value>>,
}

impl ToolExecutor for RecordedExecutor<'_> {
    fn tool_definitions(&self) -> Vec<Value> {
        self.inner.tool_definitions()
    }

    fn dispatch(&self, name: &str, args: &str) -> ToolExecutionOutput {
        let out = self.inner.dispatch(name, args);
        self.replies.lock().unwrap().push(
            serde_json::from_str(&out.output_json).expect("kernel tool returns JSON"),
        );
        out
    }
}

#[derive(Default)]
struct Observer {
    calls: Vec<ToolCallTrace>,
    turns: Vec<TurnMetrics>,
}

impl RunObserver for Observer {
    fn on_tool_call(&mut self, trace: &ToolCallTrace) {
        self.calls.push(trace.clone());
    }

    fn on_turn_complete(&mut self, metrics: &TurnMetrics) {
        self.turns.push(metrics.clone());
    }
}

fn run_case(
    client: &ResponsesClient,
    case: &Value,
    store: &FoldStore,
    envelope: &source_harness::store::FoldEnvelope,
    injector: &dyn EnvelopeInjector,
) -> Value {
    let executor = RecordedExecutor {
        inner: KernelToolExecutor { store, extra_tools: injector.extra_tool_definitions() },
        replies: Mutex::new(Vec::new()),
    };
    let input = injector.build_initial_input(case["prompt"].as_str().unwrap(), envelope);
    let mut observer = Observer::default();
    let start = Instant::now();
    let result = client.run_with_executor(
        input,
        Some("Answer accurately and concisely using the provided content or result tools."),
        &executor,
        &mut observer,
    );
    let wall_ms = start.elapsed().as_millis();
    let replies = executor.replies.into_inner().unwrap();
    let calls = observer.calls.iter().zip(replies).map(|(trace, reply)| {
        json!({ "trace": trace, "reply": reply })
    }).collect::<Vec<_>>();
    json!({
        "id": case["id"],
        "snapshot_fnv1a64": case["hash"],
        "size": case["document"].as_str().unwrap().len(),
        "lines": envelope.total_lines,
        "forced_fold": case["document"].as_str().unwrap().len() <= store.config().inline_threshold_bytes,
        "prompt": case["prompt"],
        "gold": case["gold"],
        "strategy": injector.name(),
        "model": client.config().model,
        "effort": client.config().reasoning_effort,
        "wall_ms": wall_ms,
        "final": result.as_ref().ok().map(|run| &run.final_text),
        "error": result.as_ref().err().map(ToString::to_string),
        "calls": calls,
        "turns": observer.turns,
    })
}

fn main() {
    let args = std::env::args().collect::<Vec<_>>();
    let cases: Vec<Value> = serde_json::from_slice(&fs::read(&args[1]).unwrap()).unwrap();
    let output_path = Path::new(&args[2]);
    let workers: usize = args[3].parse().unwrap();
    let only_size: usize = args[4].parse().unwrap();
    let strategy = args[5].as_str();
    let limit: usize = args[6].parse().unwrap();
    let config = GatewayConfig::from_env();
    let selected = cases.iter().filter(|case| {
        only_size == 0 || case["document"].as_str().unwrap().len() == only_size
    }).take(limit).collect::<Vec<_>>();
    let completed = AtomicUsize::new(0);
    let next = AtomicUsize::new(0);
    let output = Mutex::new(OpenOptions::new().append(true).create_new(true).open(output_path).unwrap());
    let expected = selected.len() * if strategy == "paired" { 2 } else { 1 };
    println!("Start {} cases, {} attempts, {} workers, {}, effort {:?}",
             selected.len(), expected, workers, config.model, config.reasoning_effort);
    std::thread::scope(|threads| {
        for _ in 0..workers {
            threads.spawn(|| {
                let client = ResponsesClient::new(config.clone());
                let inline = InlineUserMessageInjector;
                let native = NativeFunctionCallInjector::default();
                let mut strategies: Vec<&dyn EnvelopeInjector> = match strategy {
                    "native" => vec![&native],
                    "inline" => vec![&inline],
                    "paired" => vec![&native, &inline],
                    _ => panic!("unknown strategy {strategy}"),
                };
                loop {
                    let index = next.fetch_add(1, Ordering::Relaxed);
                    let Some(case) = selected.get(index) else { break };
                    let store = FoldStore::new();
                    let envelope = match store.ingest(case["document"].as_str().unwrap()) {
                        IngestOutcome::Folded(envelope) => envelope,
                        IngestOutcome::Inline(document) => store.insert(document),
                    };
                    if strategy == "paired" && (strategies[0].name() == "native") != (index % 2 == 0) {
                        strategies.swap(0, 1);
                    }
                    for injector in &strategies {
                        let row = run_case(&client, case, &store, &envelope, *injector);
                        writeln!(output.lock().unwrap(), "{row}").unwrap();
                        let done = completed.fetch_add(1, Ordering::Relaxed) + 1;
                        println!("[{done}/{expected}] {} {} bytes {} calls={} turns={} error={}",
                            row["id"], row["size"], injector.name(), row["calls"].as_array().unwrap().len(),
                            row["turns"].as_array().unwrap().len(), row["error"]);
                    }
                }
            });
        }
    });
}
