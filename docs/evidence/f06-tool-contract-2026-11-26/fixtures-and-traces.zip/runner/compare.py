import hashlib, json, re, statistics, subprocess
from collections import Counter
from pathlib import Path
from analyze import audit, read_events, summarize

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / "f06-regression-20261126"
FILES = {
    "paired_low": ("paired-low.jsonl", "paired-low-4k.jsonl"),
    "native_medium_64k": ("native-medium-64k.jsonl",),
    "pagination_low": ("pagination-low.jsonl",)
}

def key(row):
    return row["id"], row["size"], row["strategy"], row["effort"]

def load_previous(name):
    p = PREVIOUS / name
    return [json.loads(line) for line in p.read_text(encoding="utf8").splitlines()] if p.exists() else []

def errors(rows):
    out = []
    for row in rows:
        for c in row["calls"]:
            t = c["trace"]
            if t["status"] != "error":
                continue
            out.append(dict(id=row["id"], size=row["size"], strategy=row["strategy"], effort=row["effort"],
                            name=t["name"], turn=t["turn"], code=t["error_code"],
                            arguments=json.loads(t["arguments"]), response=c["reply"]))
    return out

def post_proof_types(rows, audited):
    counts = Counter()
    for row in rows:
        mark = audited[key(row)]["proof_call"]
        if mark is None:
            continue
        for call in row["calls"][mark:]:
            t,d = call["trace"],call["reply"].get("data", {})
            if t["status"]=="error": group="rejected"
            elif t["name"]=="read_result": group="raw_read"
            elif d.get("aggregation"): group="aggregation"
            elif d.get("scanned_lines") != [1, row["lines"]]: group="subrange"
            elif d.get("hits"): group="samples"
            else: group="other_full_search"
            counts[group]+=1
    return dict(counts)

def ordered_groups(group, before, after, audit_before, audit_after):
    sizes = [0,4096,16384,65536] if group == "paired_low" else [65536]
    result = {}
    for size in sizes:
        for arm in ("native", "inline"):
            b = sorted((r for r in before if r["strategy"] == arm and (not size or r["size"] == size)), key=key)
            a = sorted((r for r in after if r["strategy"] == arm and (not size or r["size"] == size)), key=key)
            if not b:
                continue
            bu,au = [audit_before[key(r)] for r in b], [audit_after[key(r)] for r in a]
            bt,at = summarize(bu),summarize(au)
            both_tokens = [(o["total_tokens"],n["total_tokens"]) for o,n in zip(bu,au)
                           if o["total_tokens"] is not None and n["total_tokens"] is not None]
            d = [n-o for o,n in both_tokens]
            result[f"{size or 'all'}_{arm}"] = {
                "before": bt, "after": at,
                "paired_mean_token_change_pct": round(100*sum(d)/sum(o for o,n in both_tokens),2) if d else None,
                "paired_token_delta_median": statistics.median(d) if d else None,
                "paired_token_delta_range": [min(d),max(d)] if d else None,
                "before_post_proof_calls": post_proof_types(b,audit_before),
                "after_post_proof_calls": post_proof_types(a,audit_after),
            }
    return result

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

report = dict(provenance={
    "base_commit": subprocess.check_output(["git","rev-parse","HEAD"]).decode().strip(),
    "working_diff_sha256": hashlib.sha256(subprocess.check_output(["git","diff","--binary"])).hexdigest(),
    "model_route": "auto/deepseek-v4.1-flash-1017",
    "gateway": "http://127.0.0.1:3425/v1/responses",
    "release_build_workers": 4,
    "four_kib_routing": "Both batches explicitly fold the 4096-byte cases only in the runner.",
    "method": "One draw per case and config. Previous and revised builds ran in separate batches. Prompts, fixture bytes, route and per-case settings match.",
    "counts": "Correct means the requested total or IDs were delivered; extra ID disclosures are counted separately.",
    "strict_stop": "Correct final answer with no more executed calls after sufficient evidence, including same-batch calls.",
    "artifact_sha256": {name:sha(ROOT/name) for name in ("run.rs","cases.json","pagination-cases.json","paired-low.jsonl","native-medium-64k.jsonl","pagination-low.jsonl","default-cli.json")},
}, groups={})
total = 0
for name, filenames in FILES.items():
    before = [row for f in filenames for row in load_previous(f)]
    after = [row for f in filenames for row in read_events(f)]
    assert len(before) == len(after), (name,len(before),len(after))
    assert len({key(r) for r in after}) == len(after), name
    assert sorted(key(r) for r in before) == sorted(key(r) for r in after), name
    for old,new in zip(sorted(before,key=key),sorted(after,key=key)):
        assert all(old[k] == new[k] for k in ("snapshot_fnv1a64","prompt","gold","model"))
    pagination = name == "pagination_low"
    audit_before = {key(row):audit(row,pagination=pagination) for row in before}
    audit_after = {key(row):audit(row,pagination=pagination) for row in after}
    assert max(r["max_response_bytes"] for r in audit_after.values()) <= 8192
    total += len(after)
    report["groups"][name] = {
        "summary": ordered_groups(name,before,after,audit_before,audit_after),
        "before_rejections": errors(before),
        "after_rejections": errors(after),
        "after_attempts": [audit_after[k] for k in sorted(audit_after)],
    }
assert total == 90, total
print("Matched 90 baseline and tuned observations")
cli = json.loads((ROOT/"default-cli.json").read_text())
assert cli["strategy"] == "inline" and cli["total"] == 1
report["provenance"]["observations"] = total
report["provenance"]["default_cli"] = {"strategy":cli["strategy"], "passed":cli["passed"], "total":cli["total"]}
(ROOT/"comparison.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf8")
for k,g in report["groups"].items():
    print(k, "rejections", len(g["before_rejections"]), "->",len(g["after_rejections"]))
    for label, s in g["summary"].items():
        print(label, s["paired_mean_token_change_pct"], *(tuple(s[t][m] for m in ("correct","proof","strict","mean_later","mean_tokens")) for t in ("before","after")))
