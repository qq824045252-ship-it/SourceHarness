import json, math, re, statistics
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CASES = json.loads((ROOT / "cases.json").read_text(encoding="utf8"))
BY_KEY = {c["id"]: c for c in CASES}
PAGINATION_TARGETS = (100, 380, 780)
PAGINATION_END = 900
ANSWER_FIELDS = re.compile(
    r"\b(?:total(?:\s+(?:number|count))?(?:\s+(?:of\s+)?(?:cards?\s+)?(?:marked\s+)?REVIEW(?:\s+cards?)?)?"
    r"|count|answer)(?:\s+in\s+report-\d+)?\s*(?:is|=|:)?\s*(\d+)\b"
    r"|\b(\d+)\s+(?:distinct\s+|unique\s+)?(?:cards?\b|\bREVIEW(?:\s+cards?)?\b)",
    re.IGNORECASE,
)

def build_pagination():
    items = []
    for case in [c for c in CASES if len(c["document"]) == 65536][:3]:
        lines = case["document"].splitlines()
        values = [re.fullmatch(r"card ([a-f0-9]{8}): (?:REVIEW|CLEARED)", lines[k-1])[1] for k in PAGINATION_TARGETS]
        items.append(dict(case, prompt=(
            f"Use read_result on report-{case['id']} to read lines 1 through {PAGINATION_END}, inclusive. "
            f"Begin with start_line=1 and line_count={PAGINATION_END}. When next_start_line is present, resume there "
            f"and request only the remaining lines up to {PAGINATION_END}. "
            "After reading the complete requested range, return the exact card identifiers on lines "
            f"{', '.join(map(str, PAGINATION_TARGETS))}. Use one line number and identifier per answer line."
        ), gold=dict(zip(PAGINATION_TARGETS, values))))
    (ROOT/"pagination-cases.json").write_text(json.dumps(items), encoding="utf8")

def read_events(filename):
    path = ROOT / filename
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf8").splitlines()]

def extract_answer(text):
    if not text:
        return None
    text = text.replace("**", "").replace("__", "").replace("`", "")
    if re.fullmatch(r"\s*\d+\s*[.!]?\s*", text):
        return int(re.search(r"\d+", text)[0])
    # The first claimed total is screened here. Review every final answer separately.
    match = ANSWER_FIELDS.search(text)
    return int(next(group for group in match.groups() if group is not None)) if match else None

def verify_hits(lines, status_lines, d):
    if d.get("total_lines") != len(lines) or not d.get("complete"):
        return ()
    first, last = d["scanned_lines"]
    if not 1 <= first <= last <= len(lines):
        return ()
    query, mode = d["query"], d["match_rule"]
    if mode.startswith("literal"):
        if "insensitive" in mode:
            query = query.casefold()
            matches = {n for n in range(first, last+1) if query in lines[n-1].casefold()}
        else:
            matches = {n for n in range(first, last+1) if query in lines[n-1]}
    elif mode.startswith("regex"):
        try:
            regex = re.compile(query, re.IGNORECASE if "insensitive" in mode else 0)
        except re.error:
            return ()
        matches = {n for n in range(first, last+1) if regex.search(lines[n-1])}
    else:
        return ()
    if d["matching_lines"] != len(matches) or matches != status_lines.intersection(range(first,last+1)):
        return ()
    return range(first, last+1)

def audit(row, pagination=False):
    case = BY_KEY[row["id"]]
    lines = case["document"].splitlines()
    expected = set(range(1, (PAGINATION_END if pagination else len(lines))+1))
    status_lines = {i for i, line in enumerate(lines, 1) if line.endswith(": REVIEW")}
    first = None
    coverage, read_coverage = set(), set()
    shards, errors, followups = 0, [], 0
    recorded_continuations = set()
    for i, call in enumerate(row["calls"]):
        trace, reply = call["trace"], call["reply"]
        if trace["status"] == "error":
            errors.append(trace["error_code"] or "UNKNOWN")
            continue
        d = reply.get("data", {})
        if trace["name"] == "search_result" and not pagination:
            coverage.update(verify_hits(lines, status_lines, d))
        if trace["name"] == "read_result":
            lo, hi = d["returned_line_range"]
            assert 1 <= lo <= hi <= len(lines) and d["content"].splitlines() == lines[lo-1:hi], (row["id"], lo, hi)
            followups += lo in recorded_continuations
            read_coverage.update(range(lo, hi+1))
            coverage.update(range(lo, hi+1))
            if not d["complete"]:
                assert d["next_start_line"] == hi+1
                recorded_continuations.add(d["next_start_line"])
                shards += 1
        if first is None and expected <= coverage:
            first = i
    answer = row["final"]
    if pagination:
        required = {str(k): lines[k-1].split()[1].rstrip(":") for k in PAGINATION_TARGETS}
        correct = bool(answer) and all(
            re.search(rf"\b{k}\b[^\n]*?\b{v}\b", answer, re.I) for k,v in required.items()
        )
    else:
        correct = extract_answer(answer) == row["gold"]
    review_ids = {lines[n-1].split()[1].rstrip(":") for n in status_lines}
    lists_ids = not pagination and bool(answer) and bool(review_ids.intersection(re.findall(r"\b[0-9a-f]{8}\b", answer.lower())))
    strict = correct and first is not None and first == len(row["calls"])-1
    usage = [t["usage"]["total_tokens"] for t in row["turns"]]
    full_usage = not row["error"] and bool(usage) and all(n > 0 for n in usage)
    return dict(id=row["id"], size=row["size"], strategy=row["strategy"], effort=row["effort"],
                correct=correct, lists_ids=lists_ids, answer=answer, extracted=extract_answer(answer) if not pagination else None,
                gold=row["gold"], error=row["error"], errors=errors, strict=strict, proof=first is not None,
                proof_call=None if first is None else first+1,
                tool_rounds=len({c["trace"]["turn"] for c in row["calls"]}), one_tool_round=correct and len({c["trace"]["turn"] for c in row["calls"]}) == 1,
                later_calls=None if first is None else len(row["calls"])-first-1,
                calls=len(row["calls"]), shard_pages=shards, continued_pages=followups,
                read_lines=len(read_coverage.intersection(expected)),
                total_tokens=sum(usage) if full_usage else None, recorded_tokens=sum(usage),
                wall_ms=row["wall_ms"], max_response_bytes=max((c["trace"]["response_bytes"] for c in row["calls"]), default=0))

def summarize(items):
    lat = sorted(item["wall_ms"] for item in items)
    known_tokens = [item["total_tokens"] for item in items if item["total_tokens"] is not None]
    later = [item["later_calls"] for item in items if item["later_calls"] is not None]
    counts = [item["calls"] for item in items]
    return {
        "n": len(items),
        **{key: sum(i[key] for i in items) for key in ("correct", "proof", "strict", "one_tool_round", "shard_pages", "continued_pages", "lists_ids")},
        "mean_calls": round(statistics.mean(counts), 2) if counts else None,
        "mean_later": round(statistics.mean(later), 2) if later else None,
        "mean_tokens": round(statistics.mean(known_tokens)) if known_tokens else None,
        "median_tokens": round(statistics.median(known_tokens)) if known_tokens else None,
        "token_range": [min(known_tokens), max(known_tokens)] if known_tokens else None,
        "usage_n": len(known_tokens),
        "tool_errors": dict(Counter(e for i in items for e in i["errors"])),
        "run_errors": dict(Counter(i["error"] for i in items if i["error"])),
        "max_response_bytes": max((i["max_response_bytes"] for i in items), default=0),
        "p95_wall_ms": lat[math.ceil(len(lat)*.95)-1] if lat else None,
    }

def paired(items, field):
    sides = {}
    for item in items:
        entry = sides.setdefault(item["id"], {})
        assert item["strategy"] not in entry
        entry[item["strategy"]] = item[field]
    counts = Counter((row["native"], row["inline"]) for row in sides.values()
                     if row.keys() == {"native", "inline"})
    discordant = counts[(True, False)] + counts[(False, True)]
    p = min(1, 2 * sum(math.comb(discordant, k) for k in range(min(counts[(True,False)],counts[(False,True)])+1)) / 2**discordant)
    return {"both": counts[(True,True)], "native_only": counts[(True,False)],
            "inline_only": counts[(False,True)], "neither": counts[(False,False)], "exact_p": p}

if __name__ == "__main__":
    if not (ROOT/"pagination-cases.json").exists():
        build_pagination()
    groups = {
        "paired_low": [audit(e) for name in ("paired-low.jsonl","paired-low-4k.jsonl") for e in read_events(name)],
        "native_medium_64k": [audit(e) for e in read_events("native-medium-64k.jsonl")],
        "pagination_low": [audit(e, pagination=True) for e in read_events("pagination-low.jsonl")],
    }
    stats = {}
    for group, items in groups.items():
        tiers = {}
        for size in (0,4096,16384,65536):
            subset = [i for i in items if not size or i["size"] == size]
            if not subset:
                continue
            s = {arm:summarize([i for i in subset if i["strategy"] == arm])
                 for arm in ("native","inline") if any(i["strategy"] == arm for i in subset)}
            if len(s) == 2:
                s["paired_strict"] = paired(subset, "strict")
            tiers[str(size) if size else "overall"] = s
        stats[group] = tiers
    old_64k = [c["historical"] for c in CASES if len(c["document"]) == 65536]
    stats["old_bootstrap_64k"] = {arm: {
        "correct": sum(c[arm]["correct"] for c in old_64k),
        "strict": sum(c[arm]["correct"] and c[arm]["extra_calls"] == 0 for c in old_64k),
        "mean_tokens": round(statistics.mean(c[arm]["tokens"] for c in old_64k)),
    } for arm in ("inline","synthetic")}
    (ROOT/"report.json").write_text(json.dumps({"stats":stats, "attempts":groups}, ensure_ascii=False, indent=2),encoding="utf8")
    for group, tiers in stats.items():
        print(group, json.dumps(tiers, ensure_ascii=True))
