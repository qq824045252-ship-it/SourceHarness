import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--exe", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--model", required=True)
    args = parser.parse_args()
    directory = args.out.resolve()
    directory.mkdir()
    shutil.copyfile(__file__, directory / "runner.py")
    root = directory / "workspace"
    root.mkdir()
    fixture = "".join(
        f"ROW record={i:03d} CATEGORY={'A' if i <= 128 else 'B'}\n"
        for i in range(1, 301)
    ).encode()
    (root / "catalog.txt").write_bytes(fixture)
    expected = sum(b"CATEGORY=B" in line for line in fixture.splitlines())
    prompt = (
        'Use research with scope workspace, path catalog.txt, and query "ROW" to produce a saved report of '
        'all rows. Then use search_result on that report result_ref to count lines containing "CATEGORY=B". '
        'Use the saved report, then print COUNT=<number>. Leave the workspace unchanged.'
    )
    result = subprocess.run(
        [str(args.exe.resolve()), "agent", "--root", str(root), "--session", "report", "--model", args.model,
         "--effort", "low", "--prompt", prompt],
        capture_output=True, timeout=180,
    )
    (directory / "stdout.txt").write_bytes(result.stdout)
    (directory / "stderr.txt").write_bytes(result.stderr)
    journal = root / ".sourceharness/sessions/report"
    events = [json.loads(line) for line in (journal / "events.jsonl").read_bytes().splitlines()]
    index = {e["seq"]: e for e in events}
    reports = set()
    verified = []
    for e in events:
        data = e["data"]
        if e["kind"] != "tool_result" or data["status"] != "ok":
            continue
        output = json.loads((journal / "blobs" / data["output"]).read_bytes())
        if data["name"] == "research" and output["presentation"]["matching_items"] == 300:
            reports.add(output["result_ref"])
        if data["name"] == "search_result":
            ref = index[data["attempt"]]["data"]["arguments"]
            call = json.loads((journal / "blobs" / ref).read_bytes())
            if call["result_ref"] in reports and call["query"] == "CATEGORY=B":
                verified.append(output["data"])
    text = result.stdout.decode("utf-8", "replace")
    passed = (
        result.returncode == 0
        and (root / "catalog.txt").read_bytes() == fixture
        and any(row["matching_lines"] == expected and row["complete"] for row in verified)
        and re.search(rf"\bCOUNT={expected}\b", text) is not None
    )
    report = {
        "passed": passed, "model": args.model, "expected_count": expected,
        "root_report_refs": sorted(reports), "verified_scans": verified, "stdout": text.strip(),
        "exe_sha256": sha(args.exe.read_bytes()),
    }
    (directory / "summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return int(not passed)


if __name__ == "__main__":
    raise SystemExit(main())

