import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time


def sha(value):
    return hashlib.sha256(value).hexdigest()


def events(log):
    if not log.exists():
        return []
    rows = []
    for line in log.read_bytes().splitlines():
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            break
    return rows


def wait_for(predicate, process, seconds=60):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        result = predicate()
        if result:
            return result
        if process.poll() is not None:
            raise RuntimeError(f"Chat exited early: {process.returncode}")
        time.sleep(0.015)
    raise TimeoutError("Timed out waiting for a recorded chat event")


def send(process, line):
    process.stdin.write((line + "\n").encode())
    process.stdin.flush()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--exe", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--model", required=True)
    args = parser.parse_args()
    directory = args.out.resolve()
    directory.mkdir()
    shutil.copyfile(__file__, directory / "runner.py")
    workspace = directory / "workspace"
    workspace.mkdir()
    original = b"[primary]\ntimeout=30\nretries=2\n\n[archive]\ntimeout=30\nretries=2\n"
    name = "service.cfg"
    (workspace / name).write_bytes(original)
    first = (
        "Apply this configuration change now. Use edit on service.cfg and only change the primary stanza. "
        f"The current SHA-256 is {sha(original)}. Replace the exact old stanza [primary]\\ntimeout=30\\nretries=2 "
        "with [primary]\\ntimeout=60\\nretries=3. Keep the archive unchanged."
    )
    correction = (
        "Do not modify any file. Inspect the current primary settings only. Report them as TIMEOUT=<value> "
        "and RETRIES=<value> and stop."
    )
    journal = workspace / ".sourceharness/sessions/steer"
    log = journal / "events.jsonl"
    with (directory / "stdout.txt").open("wb") as stdout, (directory / "stderr.txt").open("wb") as stderr:
        process = subprocess.Popen(
            [str(args.exe.resolve()), "chat", "--root", str(workspace), "--session", "steer",
             "--model", args.model, "--effort", "low"],
            stdin=subprocess.PIPE, stdout=stdout, stderr=stderr,
        )
        try:
            send(process, first)
            wait_for(lambda: next((e for e in events(log) if e["kind"] == "model_request"), None), process)
            send(process, f":steer {correction}")
            final = wait_for(lambda: next((e for e in events(log) if e["kind"] == "model_response"
                                           and e["data"].get("final_text") is not None), None), process)
            send(process, ":quit")
            process.wait(timeout=10)
        finally:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=10)
            process.stdin.close()
    recorded = events(log)
    steer = next(e for e in recorded if e["kind"] == "steer")
    request = next(e for e in recorded if e["kind"] == "model_request" and steer["seq"] in e["data"].get("steer_events", []))
    request_body = json.loads((journal / "blobs" / request["data"]["input"]).read_bytes())
    same_run = request["run"] == steer["run"] == final["run"]
    saw_input = any(item.get("role") == "user" and item["content"] == correction for item in request_body["input"])
    attempts = [e["data"]["name"] for e in recorded if e["kind"] == "tool_attempt"]
    cancelled = [e["data"] for e in recorded if e["kind"] == "tool_result" and e["data"].get("attempt") is None]
    text = final["data"]["final_text"]
    workspace_intact = (workspace / name).read_bytes() == original and {
        p.name for p in workspace.iterdir()
    } == {name, ".sourceharness"}
    passed = (
        process.returncode == 0 and same_run and saw_input and workspace_intact
        and "TIMEOUT=30" in text and "RETRIES=2" in text and all(action not in ("edit", "write") for action in attempts)
    )
    report = {
        "passed": passed, "model": args.model, "steering_event": steer["seq"], "next_request": request["seq"],
        "same_run": same_run, "model_received_correction": saw_input,
        "workspace_intact": workspace_intact, "tool_attempts": attempts, "unstarted_results": cancelled, "final": text,
        "exe_sha256": sha(args.exe.read_bytes()),
    }
    (directory / "summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return int(not passed)


if __name__ == '__main__':
    raise SystemExit(main())

